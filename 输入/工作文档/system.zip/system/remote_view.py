# -*- coding: utf-8 -*-
from django.shortcuts import render_to_response
from base_api import utils
import json
from base_api.base_remote import BaseRemote
from django.contrib.auth.models import User,Permission
from django.utils.log import getLogger
from django.core import serializers
import traceback
import datetime
import hashlib
from django.conf import settings
from django.utils.log import getLogger
logger = getLogger( "default" )
from django.http import HttpResponse
from django.template import RequestContext
from base_api import django_sql


class  SystemRemote(BaseRemote):
    app_label = "system"

    #对应方法调用需要的权限名称，覆盖默认的权限
    perms_define = {
        "test_port_is_ok":"test_port_is_ok__system__systemremote",
    }
    
    def test_port_is_ok(self):
        u"""
        测试某个端口的ip是否联通
        """
        from base_api import utils
        from system.models import DatabaseManage
        area = self.request.session["area"]
        area_connections = list(
            DatabaseManage.objects.filter(
                django_name__startswith=area.zcode
            )
        )
        
        not_connected = []
        
        for c in area_connections:
            if  not utils.test_db_not_or_can_connect(c):
                not_connected.append(c )
        
        result = {
            "message":u"网络OK",
            "code":0,
        }
        
        if not_connected:
            message = "<br/>".join(list(set([u"%s-%s"%(e.host,e.port) for e in not_connected])))
            result = {
                "message":u"网络连接异常，请联系运维人员排查,错误信息如下：[<br/>%s<br/>]"%message,
                "code":-1,
            }
            
        return result
    
    def get_users( self ):
        users =  json.loads(serializers.serialize("json", User.objects.all()))
        user_list = []
        for elem in users:
            user = {}
            user["id"] = elem["pk"]
            user["username"] = elem["fields"]["username"]
            user_list.append(user)
        return user_list
    
    def set_area_to_session(self,area_code):
        from system.models import Area
        area = Area.objects.get(zcode=area_code)
        
        #分配了这个区域的权限
        user_areas = self.request.session["user_areas"]
        is_ok = [ e for e in user_areas if e.zcode == area_code] 
        if self.request.user.is_superuser or is_ok:
            self.request.session["area"] = area
            return {"message":"OK","code":0}
        
        return {"message":u"没有权限修改","code":-9998}