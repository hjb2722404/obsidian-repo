# -*- coding: utf-8 -*-
from models import Area, Product,MonthProduct


def get_model_choices(attr):
    u"""
        获取模型里面的配置
    """
    from system import models

    model_attr = getattr(models, attr)
    options = []
    for t in model_attr:
        v = {"key": t[0], "value": t[1]}
        options.append(v)
   
    return options


class ProductEdit(object):
    def __init__(self, *args, **kwargs):
        super(ProductEdit, self).__init__(*args, **kwargs)

    def add_context(self, request, using_db):
        areas = Area.objects.using(using_db).all().values("id", "zname")

        return {
            "areas": areas,
            }


class MonthProductEdit(object):
    def __init__(self, *args, **kwargs):
        super(MonthProductEdit, self).__init__(*args, **kwargs)

    def custom_valid(self, request, using_db):
        pk = request.REQUEST.get("id", None)
        if pk is None:
            is_exists = MonthProduct.objects.using(using_db).filter(
                product=request.POST.get("product", 0),
            ).exists()
            if is_exists:
                return {"message":u"该产品已存在", "code":-1}
        return {"message":"", "code":0}

    def add_context(self, request, using_db):

        products = Product.objects.using(using_db).filter(is_ppv=0).values("id","area__zname", "c_name")
        tables = get_model_choices("TABLES")

        return {
            "products":products,
            "tables": tables,
            }

