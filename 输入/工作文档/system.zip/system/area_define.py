# -*- coding: utf-8 -*-
AREA_CODE_DEFINE = [
    {"zcode":u"00000","zname":u"系统区域","root_path_name":u"system","hall_type":"sd",}, #为了权限分配用
    {"zcode":u"00001","zname":u"部署后台","root_path_name":u"platform_deploy_center","hall_type":"sd",}, 
    
    {"zcode":u"90017","zname":u"江苏电信","root_path_name":u"dx_jiangsu","hall_type":"sd",},
    {"zcode":u"90018","zname":u"安徽电信","root_path_name":u"dx_anhui","hall_type":"sd",},
    {"zcode":u"90019","zname":u"广东电信","root_path_name":u"dx_guangdong","hall_type":"sd",},
    {"zcode":u"90029","zname":u"新疆电信","root_path_name":u"dx_xinjiang","hall_type":"sd",},
    {"zcode":u"9002902","zname":u"新疆电信维语","root_path_name":u"dx_xinjiang_local","hall_type":"sd",},
    {"zcode":u"90014","zname":u"湖北电信","root_path_name":u"dx_hubei","hall_type":"sd",},
    {"zcode":u"90031","zname":u"广西电信","root_path_name":u"dx_guangxi","hall_type":"sd",},
    {"zcode":u"90026","zname":u"重庆电信","root_path_name":u"dx_chongqing","hall_type":"sd",},
    {"zcode":u"90015","zname":u"湖南电信","root_path_name":u"dx_hunan","hall_type":"sd",},
    {"zcode":u"90020","zname":u"海南电信","root_path_name":u"dx_hainan","hall_type":"sd",},
    
    {"zcode":u"90021","zname":u"四川电信","root_path_name":u"dx_sichuan","hall_type":"hd",},
    {"zcode":u"80035","zname":u"深圳天威","root_path_name":u"gd_topway","hall_type":"hd",},
    {"zcode":u"8003501","zname":u"深圳天威小V","root_path_name":u"ott_gd_topway_xiaov","hall_type":"hd",},
    {"zcode":u"8003502","zname":u"深圳天威大V","root_path_name":u"ott_gd_topway_dav","hall_type":"hd",},
    {"zcode":u"80027","zname":u"天津广电","root_path_name":u"gd_tianjin","hall_type":"hd",},
    {"zcode":u"80029","zname":u"新疆广电","root_path_name":u"gd_xinjiang","hall_type":"hd",},
    {"zcode":u"8002902","zname":u"新疆广电维语","root_path_name":u"gd_xinjiang_local","hall_type":"hd",},
    {"zcode":u"80037","zname":u"厦门广电","root_path_name":u"gd_xiamen","hall_type":"hd",},
    {"zcode":u"80013","zname":u"河南广电","root_path_name":u"gd_henan","hall_type":"hd",},
    {"zcode":u"90025","zname":u"上海广电","root_path_name":u"gd_shanghai","hall_type":"hd",},

    {"zcode":u"70027","zname":u"天津联通","root_path_name":u"lt_tianjin","hall_type":"sd",},
    {"zcode":u"70024","zname":u"北京联通","root_path_name":u"lt_beijing","hall_type":"hd",},
    {"zcode":u"70036","zname":u"黑龙江联通","root_path_name":u"lt_heilongjiang","hall_type":"sd",},    
    {"zcode":u"lt_liaoning","zname":u"辽宁联通","root_path_name":u"lt_liaoning","hall_type":"sd",},    
    {"zcode":u"70027","zname":u"天津联通","root_path_name":u"lt_tianjin","hall_type":"sd",},
    {"zcode":u"ott_ceshi","zname":u"OTT外网测试","root_path_name":u"ott_ceshi","hall_type":"sd",},
    {"zcode":u"winside_iptv","zname":u"现网演示IPTV","root_path_name":u"winside_iptv","hall_type":"sd",},
]






