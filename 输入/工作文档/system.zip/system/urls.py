# -*- coding: utf-8 -*-
from django.conf.urls import *
import views
import settings_views

urlpatterns = patterns('',
    (r'^export_system_log$', views.export_system_log),
    (r'^export_system_alllog$', views.export_system_alllog),
    (r'^load_settings_page$', views.load_settings_page),
    (r'^areaparams/add$', settings_views.areaparams_add),
    (r'^areaparams/edit$', settings_views.areaparams_edit),
    (r'^exe_sql$', views.exe_sql),
    (r'^get_row_perm_html/(?P<app_label>[^/]*)/(?P<model_name>[^/]*)$', views.get_row_perm_html),
    (r'^recalculate_ppv_report', views.recalculate_ppv_report),
    (r'^recalculate_monthly_report', views.recalculate_monthly_report),
    (r'^recalculate_income_complete_report', views.recalculate_income_complete_report),
)


