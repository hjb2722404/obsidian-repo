# -*- coding: utf-8 -*-
u"""
需要行权限控制的模块，全部在这里配置
"""
from base_api import forms as base_forms

from dev.module_define import get_appinfos

ALL_ROW_PERMMISSION_MODULES = {
    "system__area":{   
        "index":1,
        "module_name":u"区域",
        "app_label":u"system",
        "model_name":u"area",
        "form":base_forms.QueryForm(
            [
                {"label":u"区域名称","name":"zname__contains","field_type":"CharField",},
                {"label":u"区域编码","name":"zcode__contains","field_type":"CharField"},
                {"label":u"区域类型","name":"hall_type__exact","field_type":"ChoiceField",
                       "choices":[["",u"---ALL---"],["hd",u"高清"],["sd",u"标清"]],
                       "widget_attrs":{"style":"width:100px"},
                },
            ]
        ),
        "columns":[
            {"field":'zname',"title":u'区域名称',"width":80,},
            {"field":'zcode',"title":u'区域编码',"width":80,"sortable":True},
        ],
    },
    "dev__svncode":{
        "index":2,
        "module_name":u"应用",
        "app_label":u"dev",
        "model_name":u"svncode",
        "form":base_forms.QueryForm(
           [
               {"label":u"区域名称","name":"area__zname__contains","field_type":"CharField",},
               {
                    "label":u"应用",
                    "name":"app__in",
                    "field_type":"MulChoiceField",
                    "choices":get_appinfos,   
                    "widget_attrs":{"style":"width:150px"},
               },
           ]
        ),
        "columns":[
            {"field":'area__zname',"title":'区域名称',"width":100},
            {"field":'app',"title":'应用名称',"width":150},
        ],
    },
}


