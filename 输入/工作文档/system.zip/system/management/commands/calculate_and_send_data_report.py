# -*- coding: utf-8 -*-
from django.core.management.base import BaseCommand
import datetime
import threading
import time

__doc__ = u"""
    1、计算日报表
        a、按次ppv计算--存储到数据库
        b、包月产品计算--存储到数据库
        c、读取数据库表ppv，包月报表中的数据
    2、计算完成度报表
    3、根据1,2 计算的结果，整合成excel格式，发送到报表需求人的邮箱

    多线程设计
       由于大部分的时间都是在远程服务器上面计算，为了提高计算的速度，调用采用多线程，
       由于发送需要等计算之后才能做，又需要考虑到顺序性
"""

class Command(BaseCommand):
    option_list = BaseCommand.option_list + ()
    help = u"每次凌晨统计上一天的ppv,以及包月报表，并邮件发送"
    args = ''

    def handle(self, *args, **options):
        from system.day_report_calculate_3 import save_ppv_day_data
        from system.email_for_excel_day_report import send_email2user
        from system.day_report_calculate_3 import save_monthly_day_data
        from system.day_report_calculate_3 import save_monthly_month_data

        #计算ppv产品每日报表
        yestoday = datetime.datetime.today().date() - datetime.timedelta(days=1)
        t1 = threading.Thread(target=save_ppv_day_data,kwargs = {"calculate_date":yestoday})
        t1.start()

        #计算包月产品每日报表
        t2 = threading.Thread(target=save_monthly_day_data,kwargs = {"calculate_date":yestoday,})
        t2.start()


        t1.join()
        t2.join()

        #计算汇总的报表,由于该报表的结果是建立在前面两个线程结果的基础之上，
        # 所以这里要等前面两个结果结束之后才能往下走。
        save_monthly_month_data(calculate_date=yestoday)

        #三个线程计算完成之后>>>由于生成的结果，需要人核实，可能还需要编辑，所以需要隔3个小时后再发送
        time.sleep(3*60*60)
        #根据计算结果，整合成excel，以附件的方式
        send_email2user(yestoday) # 邮件发送收入完成度月报表