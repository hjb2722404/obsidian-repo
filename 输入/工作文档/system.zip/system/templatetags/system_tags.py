# -*- coding: utf-8 -*-
from django import template
from system import utils
register = template.Library()


@register.filter
def has_perm(request,perm_name):
    u"""
    判断用户是否有某个权限
    @perm_name 权限名称,例如:browse__system__user
       {% if request|has_perm:"browse__system__user" %}
           OK
       {% else %}
           NO 
       {% endif %}
    """
    user = request.user
    area = request.session.get("area",None)
    user_perms = request.session.get("perms",None)
    return utils.has_perm(user,area,user_perms,perm_name)
