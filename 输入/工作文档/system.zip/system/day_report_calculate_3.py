# -*- coding: utf-8 -*-
import traceback
from system.models import MonthProduct
from system.models import PpvProduct
from system.models import PpvDayTotalReport
from system.models import MonthDayTotalReport
from system.models import Product
from system.models import DataSyncConfig
from day_report_klass import PpvDayReportCal
from day_report_klass import MonthlyDayReportCal
from day_report_klass import TotalMonthReportCal

from django.utils.log import getLogger
logger = getLogger( "default" )

def save_ppv_day_data(calculate_date,ppv_products_ids = None):
    u"""保存ppv每日数据
        calculate_date->统计的日期
        areas ->需要统计的地区
        @return True ->统计成功 | False ->统计失败
    """
    IS_PPV_PRODUCT = 1 #是ppv产品
    SYSTEM_AUTO_CALCULAT = 0 #系统自动统计

    if not ppv_products_ids: #默认使用全部已经配置了的可以自动统计的产品
        ppv_products = PpvProduct.objects.filter(
            product__is_ppv= IS_PPV_PRODUCT,
            product__new_by_hand = SYSTEM_AUTO_CALCULAT,
        ).values(
            "c_pv_key","limit_money","product__area__id","product__c_name","product__area__zcode","is_ott",
        ).order_by("product__area__zcode")
    else:
        ppv_products = PpvProduct.objects.filter(
            product__is_ppv= IS_PPV_PRODUCT,
            product__new_by_hand = SYSTEM_AUTO_CALCULAT,
            id__in = ppv_products_ids,
        ).values(
            "c_pv_key","limit_money","product__area__id","product__c_name","product__area__zcode","is_ott",
        ).order_by("product__area__zcode")

    flag = False
    for ppv_product in ppv_products:
        try:
            #保存ppv数据
            conn = DataSyncConfig.objects.filter(db__django_name=ppv_product["product__area__zcode"]).first()
            if not conn:#导数据的连接未配置，数据查询不了
                logger.info(u"save_ppv_day_data->zcode=[{zcode}],areaname = [{areaname}] sync connection not exists]".format(
                    zcode = ppv_product["product__area__zcode"],
                    areaname = ppv_product["product__area__zcode"],
                    )
                )
            else:
                using_db = conn.alias
                ppv_record ={}
                t = PpvDayReportCal(
                    ppv_product,
                    calculate_date,
                    using_db,
                ).get_ppv_day_report_record()
                fields = [
                    "fdate",
                    "product_name",
                    "dis_hall_access_uv",
                    "hall_access_pv",
                    "dis_game_start_uv",
                    "game_start_pv",
                    "p_success_money",
                    "p_fail_money",
                    "p_success_dis_count",
                    "p_total_dis_count",
                    "p_total_count",
                    "success_percent",
                    "day_new_user",
                    "p_new_add_count",
                    "ARPU",
                    "c_success_money",
                    "c_fail_money",
                    "c_total_dis_count",
                    "c_total_count",
                    "c_new_add_count",
                    "count_month_limit_user",
                    "month_limit_money",
                    "coins_percent",
                    "daily_pay_percent",
                    "total_user",
                    "total_pay_user",
                    "no_pay_user",
                    "is_warning",
                    "area_id",
                ]
                #***只选择需要的字段保存***
                for k,v in t.items():
                    if k in fields:
                        ppv_record[k] = v

                is_exists = PpvDayTotalReport.objects.filter(
                    fdate=ppv_record["fdate"],
                    area_id=ppv_record["area_id"],
                    product_name = ppv_product["product__c_name"],
                ).exists()

                if not is_exists:
                    PpvDayTotalReport(**ppv_record).save()
                else:
                    PpvDayTotalReport.objects.filter(
                        fdate=ppv_record["fdate"],
                        area_id=ppv_record["area_id"],
                        product_name = ppv_product["product__c_name"],
                    ).update(**ppv_record)
                flag = True
        except:
            logger.info(u"save_ppv_day_data->zcode=[{zcode}],areaname = [{areaname}],except=[{exp}]".format(
                    zcode = ppv_product["product__area__zcode"],
                    areaname = ppv_product["product__c_name"],
                    exp = traceback.format_exc(),
                )

            )

    return flag

def save_monthly_day_data(calculate_date,monthly_products_ids = None):
    #保存包月的数据
    IS_NOT_PPV_PRODUCT = 0 #包月产品
    SYSTEM_AUTO_CALCULAT = 0 #系统自动统计
    if not monthly_products_ids: #没有传递，默认用所有地区的产品
        month_products  = MonthProduct.objects.filter(
            product__is_ppv = IS_NOT_PPV_PRODUCT,
            product__new_by_hand=SYSTEM_AUTO_CALCULAT,
        ).values(
            "product__area__id","product__area__zcode","product__area__zname","product__c_name","c_pay_key","c_pv_key","c_table","ratio","price",
        ).order_by("product__area__zcode")
    else:
        month_products  = MonthProduct.objects.filter(
            product__is_ppv = IS_NOT_PPV_PRODUCT,
            product__new_by_hand=SYSTEM_AUTO_CALCULAT,
            id__in = monthly_products_ids,
        ).values(
            "product__area__id","product__area__zcode","product__area__zname","product__c_name","c_pay_key","c_pv_key","c_table","ratio","price",
        ).order_by("product__area__zcode")

    flag = False
    for product_obj in month_products:
        try:
            #保存ppv数据
            conn = DataSyncConfig.objects.filter(db__django_name=product_obj["product__area__zcode"]).first()
            if not conn:#导数据的连接未配置，数据查询不了
                logger.info(u"save_monthly_day_data->zcode=[{zcode}],areaname = [{areaname}] sync connection not exists".format(
                    zcode = product_obj["product__area__zcode"],
                    areaname = product_obj["product__area__zname"],
                    )
                )
            else:
                using_db = conn.alias
                t = MonthlyDayReportCal( product_obj,calculate_date,using_db).get_monthly_day_report_record()
                fields = [
                    "fdate",
                    "product_name",
                    "dis_hall_access_uv",
                    "hall_access_pv",
                    "p_success_dis_count",
                    "c_percent",
                    "dis_order_page_user_uv",
                    "day_new_user",
                    "dis_total_first_login_and_order_user",
                    "dis_hall_already_order_count",
                    "success_percent",
                    "p_fail_dis_count",
                    "dis_game_start_uv",
                    "game_start_pv",
                    "p_success_money",
                    "p_subscribe_success_money",
                    "p_fail_money",
                    "p_new_add_count",
                    "order_page_user_pv",
                    "total_user",
                    "total_pay_user",
                    "no_pay_user",
                    "area_id",
                ]

                monthly_record = {}
                for k,v in t.items(): #获取需要的字段
                    if k in fields:
                        monthly_record[k]= v

                is_exists = MonthDayTotalReport.objects.filter(
                    product_name=monthly_record["product_name"],
                    fdate=monthly_record["fdate"],
                    area_id=monthly_record["area_id"]
                ).exists()

                if not is_exists:
                    MonthDayTotalReport(**monthly_record).save()
                else:
                    MonthDayTotalReport.objects.filter(
                        product_name=monthly_record["product_name"],
                        fdate=monthly_record["fdate"],
                        area_id=monthly_record["area_id"]
                    ).update(**monthly_record)

                flag = True
        except:
            logger.info(u"save_monthly_day_data->zcode=[{zcode}],areaname = [{areaname}] exp=[{exp}]".format(
                    zcode = product_obj["product__area__zcode"],
                    areaname = product_obj["product__area__zname"],
                    exp = traceback.format_exc(),
                )
            )

    return flag


def get_group_areas(calculate_pks = None,is_need_filter=True):
    u"""
    得到分组的区域
    @is_need_filter 是否需要过滤掉手动统计的地区
    """
    from system.models import Area
    #某些区域的数据合并到某一个大地区
    data_merge_areas = { #key-->合并之后数据存储到哪个区代码,value--> 需要合并的地区代码列表
        "90029":["90029","9002902"], #新疆电信
        "80029":["80029","8002902"], #新疆广电
    }

    SYSTEM_AUTO_CALCULAT = 0
    STOP_CALCULAT = 2
    if is_need_filter:
        zcodes = Product.objects.filter(new_by_hand= SYSTEM_AUTO_CALCULAT).values_list("area__zcode")
    else:
        zcodes = Product.objects.exclude(new_by_hand= STOP_CALCULAT).values_list("area__zcode")

    areas = Area.objects.filter(zcode__in = zcodes).order_by("id")

    #给所有的区域分组
    group_areas = {}
    for area_obj in areas:
        is_merged = False
        for k,v in data_merge_areas.items():
            if area_obj.zcode in v: #合并的地区
                group_areas.setdefault(k,[]).append(area_obj)
                is_merged = True

        if not is_merged: #没有合并的地区
            group_areas.setdefault(area_obj.zcode,[]).append(area_obj)


    vs = group_areas.values() #地区转换成分组的对象
    def filter_func(obj):
        u"判断某个分组批次，是否在需要统计的列表中"
        for e in obj:
            if e.pk in calculate_pks:
                return True
        return False

    if calculate_pks: #知道对于的分组批次
        vs = filter(filter_func,vs)

    return vs

def save_monthly_month_data(calculate_date,calculate_pks = None,):
    u"""
    保存包月月报表
    """

    from system.models import IncomeTotalReport
    flag = False
    vs = get_group_areas(calculate_pks)
    for elem in vs:
        try:
            area_obj = elem[0]
            merge_areaids = [ e.id for e in elem]
            record = TotalMonthReportCal( area_obj,merge_areaids,current_date=calculate_date).get_current_month_report_record()
            is_exists = IncomeTotalReport.objects.filter(
                month=record["month"],
                area_id=record["area_id"],
            ).exists()
            if not is_exists:
                IncomeTotalReport(**record).save()
            else:
                IncomeTotalReport.objects.filter(
                    month=record["month"],
                    area_id=record["area_id"],
                ).update(**record)

            flag = True
        except:
            logger.info(u"zcodes=[{zcodes}],areaname = [{znames}],exp=[{exp}]".format(
                zcodes = u",".join([e.zcode for e in elem]),
                znames = u",".join([e.zname for e in elem]),
                exp = traceback.format_exc(),
                )
            )

    return flag
            
        

