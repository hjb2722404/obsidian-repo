# -*- coding: utf-8 -*-
from django.contrib.auth.backends import  ModelBackend
from django.contrib.auth import get_user_model
import random

_letter_cases = "abcdefghjkmnpqrstuvwxy" # 小写字母，去除可能干扰的i，l，o，z
_upper_cases = _letter_cases.upper() # 大写字母
_numbers = ''.join(map(str, range(2, 10))) # 数字

def get_random_char(s):
    length = len(s)
    index = random.randint(0,length-1)
    return s[index]

def get_random_password(length):
    u"""
    生成随机密码
    """
    d = {
        0:_letter_cases,
        1:_upper_cases,
        2:_numbers,
    }
    result = []
    for i in range(length):
        index = random.randint(0,2)
        elem = get_random_char(d[index])
        result.append(elem)
        
    return "".join(result)

class MyModelBackend(ModelBackend):
    u"""
    验证用户正确与否的后端
    """
    def authenticate(self, username=None, password=None,first_name=None):
        UserModel = get_user_model()
        password = get_random_password(8)
        user_obj,is_new = UserModel.objects.get_or_create(
                username=username,defaults={
                    "username":username,
                    "first_name":first_name,
                    "password":password,
                    "email":"%s@winside.cn"%username,
                    "is_active":True
                }
        )
        return user_obj