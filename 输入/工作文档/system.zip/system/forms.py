# -*- coding: utf-8 -*-
from django import forms
from django.conf import settings
from django.contrib.auth.hashers import make_password
from django.core.cache import cache
from django.forms import ModelForm
from django.forms import fields as form_fields
from django.utils.log import getLogger
from base_api import widget
from base_api.middleware import threadlocals
from system.models import DatabaseManage
from system.models import LogEntry,IncomeTotalReport,PpvDayTotalReport,MonthDayTotalReport,\
        MonthProductParams,PpvProductParams,ReceiverConfig
from system.models import DataSyncConfig
import decimal
from system.models import RetryTask
import os
import traceback
from system.models import SyncLog
from system.models import User,Group,Permission,Area
from system.models import TestUser
from base_api import tree_widget
import json

logger = getLogger( "default" )


class UserForm(ModelForm):
    
    def clean_is_superuser(self):
        u"""
        超级管理员验证
        """
        value = self.cleaned_data.get("is_superuser",False)
            
        request=threadlocals.get_current_request()
        
        if not request.user.is_superuser:
            raise forms.ValidationError( u"不是超级管理员不能修改" )
    
        return value
    
    
    def get_password(self, raw_password):
        return make_password(raw_password)
    
    def clean_password(self):
        value = self.cleaned_data.get("password","")
        
        if len(value)<6:
            raise forms.ValidationError(u"密码长度不少于6位。")
        if self.instance.pk and self.instance.password == value:
            return value
        
        value = self.get_password(value)
        return value
    
    def add_fields(self,request,instance, *args, **kwargs):
        u"""增加用户区域字段"""
        from system.models import Area
        from system.models import UserRowPermission
        
        qs_user_row_perms = UserRowPermission.objects.all()
        initial_row_perm = None
        
        qs = Area.objects.all()
        initial = None
        
        user = request.user
        
        if instance:
            initial_row_perm = UserRowPermission.objects.filter(user__id = instance.pk).first()
            if initial_row_perm:
                initial_row_perm = initial_row_perm.pk
            
        self.fields["row_perms"] = forms.ModelMultipleChoiceField(
            queryset=qs_user_row_perms,
            initial = initial_row_perm,
            label=u"行级权限",
            widget=widget.WidgeRowPermissionSelect(attrs={"style": "height:35px;width:200px",})
        )

    
    def after_save(self, request, instance, *args, **kwargs):
        u"""
        保存用户区域字段
        """
        from system.models import UserRowPermission
        import json
        
        #保存创建者
        user = request.user
        if not instance.create_user:
            instance.create_user = user
            instance.save()
            
        #保存用户行级权限
        row_perms = request.REQUEST.get("row_perms",None)
        system_area_code = "00000"
        if row_perms and json.loads(row_perms):
            user_row_perm_obj = UserRowPermission.objects.filter(user__pk = instance.pk,areacode= system_area_code).first()
            old_verboses = ""
            new_verboses = ""
            if user_row_perm_obj:
                old_verboses = user_row_perm_obj.all_filters
                user_row_perm_obj.all_filters=row_perms
                user_row_perm_obj.save()
                new_verboses = row_perms
            else:
                UserRowPermission(
                    all_filters=row_perms,
                    user_id=instance.pk,
                    areacode =system_area_code 
                ).save()
                new_verboses = row_perms
            
            LogEntry.log_self(
                request.user.pk,
                "change",
                None,
                u"对%s用户操作:修改行权限：%s--新行权限：%s"%(
                    instance,
                    old_verboses,
                    new_verboses
                ),
                model_cls=UserRowPermission,
                area_id = Area.objects.get(zcode="00000").pk
            )
        
    class Meta:
        model = User
        fields = [
            "username","password","first_name","last_name","email",
            "is_active","is_superuser","user_permissions",
            "groups", 
        ]
        widgets ={
            "user_permissions":widget.WigetPermissionTree(attrs={}),
            "groups":widget.WidgetMultipleSelect(attrs={"style": "height:35px;width:200px"}),
            "password":forms.PasswordInput(
                attrs={"class":"easyui-validatebox","data-options":"required:true"},
                render_value=True
            ),
            "email":forms.TextInput(attrs={"class":"easyui-validatebox","data-options":"required:true,validType:'email'"},)
        }
        labels = {"user_permissions":u"用户权限","groups":u"角色" }
        help_texts = {
            "user_permissions": u"",
        }


class GroupForm(ModelForm):
    class Meta:
        model = Group
        fields = ["name","permissions"]
        widgets ={
            "permissions":widget.WigetPermissionTree(
                attrs={
                
                }
            )
        }
        
        labels = {"permissions":u"角色权限" }
        help_texts = {
            "permissions": u"",
        }
        error_messages = {}
        

class AreaForm(ModelForm):
    def add_fields(self,request,instance, *args, **kwargs):
        u"""增加用户区域字段"""
        from system.models import AreaPermission
        qs = Permission.objects.all()
        user = request.user
        initial = None
        if instance:
            initial = AreaPermission.objects.filter(area__id = instance.pk).values_list("permission__id",flat=True)
            
        self.fields["permission"] = forms.ModelMultipleChoiceField(
            queryset=qs,initial = initial,
            widget =widget.WigetPermissionTree(),
            label=u"区域"
        )
    
    
    def after_save(self, request,instance,*args, **kwargs):
        from system.models import AreaPermission
        permissions = request.REQUEST.getlist("permission")
        
        user = request.user
        
        exist_permission = AreaPermission.objects.filter(area__id = instance.pk ).values_list("permission_id",flat= True)
        
        need_create_pks = []
        not_delete_pks = []
        
        for pk in permissions:
            if int(pk) not in exist_permission:
                need_create_pks.append(pk)
            else:
                not_delete_pks.append(pk)
        
        #删除取消掉的
        qs = AreaPermission.objects.filter(area__id = instance.pk).exclude(permission__id__in = not_delete_pks)
        del_verboses = u",".join([ e.permission.name for e in qs])
        qs.delete()
        
        
        #新增
        new_verboses = []
        if need_create_pks:
            for pk  in need_create_pks:
                obj = AreaPermission()
                obj.area_id = instance.pk
                obj.permission_id = pk
                obj.save()
                new_verboses.append(obj.permission.name)
                
        new_verboses = u",".join(new_verboses)
    
        LogEntry.log_self(
            request.user.pk,
            "change",
            None,
            u"对%s区域权限操作:删除了权限：%s--新增了权限：%s"%(
                instance,
                del_verboses,
                new_verboses
            ),
            model_cls=AreaPermission,
            area_id = Area.objects.get(zcode="00000").pk
        )
        
    
        cache_key = "%(prex)s_%(area_code)s"%{"prex":settings.CACHE_PREX_AREA_PERMISSION,"area_code":instance.zcode}
        cache.delete(cache_key)
    
    class Meta:
        model = Area
        fields = ["parent","zcode","zname","root_path_name","hall_type", "c_sort"]
        
        widgets ={
            "parent" :  tree_widget.WidgetTreeDropDown(attrs={
                "style":"width:150px",
                "limit":True
            }),
        }
    
class SyncLogForm(ModelForm):
    class Meta:
        model = SyncLog
        fields = ["max_order_id"]
        widgets ={}
        labels = {}
        help_texts = {}
        error_messages = {}


class RetryTaskForm(ModelForm):
    class Meta:
        model = RetryTask
        fields = ["retry_start_time","retry_end_time"]
        widgets ={}
        labels = {}
        help_texts = {}
        error_messages = {}
        

class TestUserForm(ModelForm):
    def init_zsjform(self, request, *args, **kwargs):
        from base_api.utils import redirect
        url = "%s/remote/CollectDataRemote/get_all_areanames/"%settings.OPTIONS["GENERATE_API_ROOT_PATH"]
        userids = json.loads(redirect(url))
        initial = None
        if self.instance.pk is not  None:
            initial = self.instance.areaname
    
        self.fields["areaname"] = form_fields.ChoiceField(choices=userids,label=u"用户ID",widget=widget.WidgetSingleSelect)
    
    class Meta:
        model = TestUser
        fields = ["areaname","c_userid","remark"]
        widgets ={}
        labels = {}
        help_texts = {}
        error_messages = {}
    

class DatabaseManageForm(ModelForm): 
    def clean_django_name(self):
        import re
        value = self.cleaned_data.get("django_name","")
        if re.compile("^[a-zA-Z_1234567890]+$").match(value):
            return value
        else:
            raise  forms.ValidationError( u"连接名称必须是数字，字母，或者下划线" )

    def clean_other_dbs(self):
        import re
        value = self.cleaned_data.get("other_dbs","")
        if re.compile("^[a-zA-Z_1234567890,]*$").match(value):
            return value
        else:
            raise  forms.ValidationError( u"多个数据库以逗号隔开，数据库名称必须是数字，字母，或者下划线" )

    def init_zsjform(self, request, *args, **kwargs):
        from system.models import Area

        if self.instance.pk is None:
            zcodes = Area.objects.values_list("zcode","zname")
            self.fields.update(
                    {
                        "django_name":form_fields.ChoiceField(choices=zcodes,label=u"地区选择",widget=widget.WidgetSingleSelect),
                        "other_dbs": form_fields.CharField(required=False,label=u"其他数据库",help_text=u"以逗号隔开",widget=widget.WidgetText(
                            attrs = {"style":"width:350px;"}
                        )),
                 }
            )

    def save(self, commit=True):
        import os
        from system.models import DatabaseManage
        from django.db import transaction
        if self.instance.pk is None:
            data = self.cleaned_data
            if data["applabel"] == "game":
                main_django_name = data["django_name"]
            else:
                main_django_name ="{django_name}_{applabel}".format(
                    django_name = data["django_name"],
                    applabel = data["applabel"]
                )

            with transaction.atomic():
                #main instance
                instance = DatabaseManage.objects.filter(django_name=main_django_name).first()
                if not instance:
                    instance = DatabaseManage(
                        django_name = main_django_name,
                        dbname = data["dbname"],
                        username = data["username"],
                        password = data["password"],
                        game_host = data["game_host"],
                        port = data["port"],
                        host = data["host"],
                        applabel = data["applabel"],
                        is_main_db = data["is_main_db"],
                        remark = data["remark"],
                    )
                    instance.save()

                if data["other_dbs"]:#数据库连接名称跟加上应用前缀，数据库名称不变
                    for dbname in data["other_dbs"].strip().split(","):
                        if not dbname:
                            continue
                        t_django_name = "{m}_{n}".format(m = main_django_name,n = dbname)
                        if not DatabaseManage.objects.filter(django_name=t_django_name).exists():
                            DatabaseManage(
                                django_name = t_django_name,
                                dbname = dbname,
                                username = data["username"],
                                password = data["password"],
                                game_host = data["game_host"],
                                port = data["port"],
                                host = data["host"],
                                applabel = data["applabel"],
                                remark = data["remark"]
                            ).save()
            return_obj =  instance

        else:
            return_obj =  super(DatabaseManageForm, self).save()
        
        #加载apache，加载数据库连接
        cmd = u"sudo /etc/init.d/httpd reload"
        os.system(cmd)
        return return_obj

    class Meta:
        model = DatabaseManage
        fields = ["django_name","dbname","username","password","host","game_host","port","is_main_db","applabel","remark"]
        widgets = {}
        labels = {}
        help_texts = {}
        error_messages = {}

class DataSyncConfigForm(ModelForm): 
    def init_zsjform(self, request, *args, **kwargs):
        qs = DatabaseManage.objects.filter(is_main_db = "T")

        initial = None
        if self.instance.pk is not  None:
            initial = self.instance.db_id
        else:
            is_exists_ids=  DataSyncConfig.objects.values_list("db_id",flat=True)
            qs = qs.exclude(id__in = is_exists_ids)

        self.fields["db"] = forms.ModelChoiceField(
            queryset=qs,
            initial = initial,
            label=u"数据库连接",
            widget=widget.WidgetSingleSelect(attrs={"style": "height:35px;width:300px",})
        )

    def after_save(self,request,*args,**kwargs):
        u"""
        不管新增还是编辑，都同步一下数据库，让导数据的应用有保存数据标记的记录
        """
        try:
            os.system("python /var/www/data_sync/manage_insert_rabbitmq.py syncdb --settings=dmysite.settings_insert_rabbitmq_syncdb")
        except:
            logger.info("DataSyncConfigForm after_save cmd exceptions='%s'"%traceback.format_exc())

    class Meta:
        model = DataSyncConfig
        fields = [
            "db","is_consume_pay_on","is_pv_on","is_edu_resource_on","is_month_pay_on","is_loginpv_on",
            "is_user_on","alias","merge_with_end","enable",
        ]
        widgets = {}
        labels = {}
        help_texts = {}
        error_messages = {}
        
        
class MonthProductParamsForm(ModelForm):
    def __init__(self,*args,**kwargs):
        super(MonthProductParamsForm,self).__init__(*args,**kwargs)

    def custom_valid(self, request, instance, using_db):
        import datetime
        pk = request.REQUEST.get("id", None)
        if pk is None:
            date = datetime.datetime.strptime(request.POST.get("month",""),'%Y-%m-%d').date()
            year = date.strftime("%Y")
            month = date.strftime("%m")
            is_exists = MonthProductParams.objects.using(using_db).filter(
                month__year=year,
                month__month = month,
                product=request.POST.get("product", 0),
            ).exists()
            if is_exists:
                return {"message":u"该月份的产品配置已存在", "code":-1}
        return {"message":"", "code":0}

    def init_zsjform(self, request, *args, **kwargs):
        from models import MonthProduct
        from base_api import form_fields  as f_field
        using_db = kwargs["using_db"]
        product_qs = MonthProduct.objects.using(using_db).all()

        product_initial = None

        if self.instance:
            product_initial = MonthProduct.objects.using(using_db).filter(id=self.instance.product_id)

        self.fields["product"] = f_field.ZsjModelChoiceField(
            queryset=product_qs,
            initial=product_initial,
            label=u"地区-产品选择",
            widget=widget.WidgetSingleSelect(attrs={"style": "width:150px"})
        )

    def save(self, commit=True):
        from system.models import MonthProductParams
        if self.instance.pk is None:
            data = self.cleaned_data
            instance = MonthProductParams(
                month=data["month"],
                product_id=data["product"].id,
                continue_subscribe_numbers=data["continue_subscribe_numbers"],
                income_target=data["income_target"]
            )
            instance.save()
            return_obj = instance
        else:
            return_obj = super(MonthProductParamsForm, self).save()
        return return_obj

    class Meta:
        model = MonthProductParams
        fields = [
            "month", "product", "continue_subscribe_numbers","income_target","remark"
        ]
        widgets ={
            "month" :  widget.WidgetMonth(attrs={"style":"width:150px",}),
            "continue_subscribe_numbers" : widget.WidgetValidateText(attrs={"style":"width:150px",}),
            "income_target" : widget.WidgetValidateText(attrs={"style":"width:150px",}),
            "remark" : widget.WidgetTextarea()
        }


class PpvProductForm(ModelForm):
    def __init__(self,*args,**kwargs):
        super(PpvProductForm,self).__init__(*args,**kwargs)

    def init_zsjform(self, request, *args, **kwargs):
        from models import Product
        from models import PpvProduct
        from base_api import form_fields as f_field
        using_db = kwargs["using_db"]
        product_qs = Product.objects.using(using_db).filter(is_ppv=1)
        product_initial = None
        if self.instance.pk:
            product_initial = Product.objects.using(using_db).filter(id=self.instance.product_id)
        else:
            exist_ids =  list(PpvProduct.objects.values_list("product_id",flat=True))
            product_qs = product_qs.exclude(
                pk__in=exist_ids
            )

        self.fields["product"] = f_field.ZsjModelChoiceField(
            queryset=product_qs,
            initial=product_initial,
            label=u"地区-产品选择",
            widget=widget.WidgetSingleSelect(attrs={"style": "width:200px"})
        )

    class Meta:
        from models import PpvProduct
        model = PpvProduct
        fields = [
            "product", "c_pv_key","limit_money","is_ott",
        ]
        widgets ={
            "c_pv_key": widget.WidgetValidateText(attrs={"style":"width:150px",}),
            "limit_money" : widget.WidgetValidateText(attrs={"style":"width:150px",}),
        }


class PpvProductParamsForm(ModelForm):
    def __init__(self,*args,**kwargs):
        super(PpvProductParamsForm,self).__init__(*args,**kwargs)

    def custom_valid(self, request, instance, using_db):
        import datetime
        pk = request.REQUEST.get("id", None)
        if pk is None:
            date = datetime.datetime.strptime(request.POST.get("month",""),'%Y-%m-%d').date()
            year = date.strftime("%Y")
            month = date.strftime("%m")
            is_exists = PpvProductParams.objects.using(using_db).filter(
                month__year=year,
                month__month = month,
                product=request.POST.get("product", 0),
            ).exists()

            if is_exists:
                return {"message":u"该月份的产品配置已存在", "code":-1}

        return {"message":"", "code":0}

    def init_zsjform(self, request, *args, **kwargs):
        from models import PpvProduct
        from base_api import form_fields  as f_field
        using_db = kwargs["using_db"]
        product_qs = PpvProduct.objects.using(using_db)

        product_initial = None
        if self.instance:
            product_initial = PpvProduct.objects.using(using_db).filter(id=self.instance.product_id)

        self.fields["product"] = f_field.ZsjModelChoiceField(
            queryset=product_qs,
            initial=product_initial,
            label=u"地区-产品选择",
            widget=widget.WidgetSingleSelect(attrs={"style": "width:200px"})
        )

    def save(self, commit=True):
        if self.instance.pk is None:
            data = self.cleaned_data
            instance = PpvProductParams(
                month=data["month"],
                product_id=data["product"].id,
                income_target=data["income_target"]
            )
            instance.save()
            return_obj =  instance
        else:
            return_obj =  super(PpvProductParamsForm, self).save()
        return return_obj

    class Meta:
        model = PpvProductParams
        fields = [
            "month", "product","income_target","remark"
        ]
        widgets ={
            "month" :  widget.WidgetMonth(attrs={"style":"width:150px",}),
            "income_target" : widget.WidgetValidateText(attrs={"style":"width:150px",}),
            "remark" : widget.WidgetTextarea()
        }


class IncomeTotalReportForm(ModelForm):
    def __init__(self,*args,**kwargs):
        super(IncomeTotalReportForm,self).__init__(*args,**kwargs)

    def custom_valid(self, request, instance, using_db):
        import datetime
        pk = request.REQUEST.get("id", None)
        if pk is None: #新增
            date = datetime.datetime.strptime(request.POST.get("month", ""),'%Y-%m-%d').date()
            area = request.POST.get("area", "")
            is_exists = IncomeTotalReport.objects.using(using_db).filter(
                month=date,
                area=area
            ).exists()
            if is_exists:
                return {"message": u"""日期:%s，该地区已经存在,请调整。"""%(date), "code":-1}

        return {"message":"", "code": 0}

    def save(self, commit=True):
        data = self.cleaned_data
        instance =  super(IncomeTotalReportForm,self).save()
        instance.ppv_complete_rate = decimal.Decimal(data["ppv_sum_money"]) / decimal.Decimal(data["ppv_income_target"]) if data["ppv_income_target"] else 0
        instance.monthly_complete_rate = decimal.Decimal(data["month_sum_money"]) / decimal.Decimal(data["monthly_income_target"]) if data["monthly_income_target"] else 0
        instance.total_sum_money = (data["ppv_sum_money"] +  data["month_sum_money"])
        instance.income_target = data["ppv_income_target"] +  data["monthly_income_target"]
        instance.complete_rate = decimal.Decimal(instance.total_sum_money)  /decimal.Decimal(instance.income_target) if instance.income_target else 0
        instance.save()
        return instance


    class Meta:
        model = IncomeTotalReport
        fields = [
            "month", "area", "ppv_sum_money", "ppv_income_target","ppv_complete_rate","month_sum_money","monthly_income_target",
            "monthly_complete_rate","total_sum_money", "income_target","complete_rate","remark"
        ]
        widgets ={
            "month" : widget.WidgetDate(attrs={"style":"width:150px",}),
            "ppv_sum_money" : widget.WidgetNumber(attrs={"style":"width:150px",}),
            "ppv_income_target": widget.WidgetNumber(attrs={"style":"width:150px",}),
            "ppv_complete_rate" : widget.WidgetDisabledText(attrs={"style":"width:150px",}),

            "month_sum_money" : widget.WidgetNumber(attrs={"style":"width:150px",}),
            "monthly_income_target" : widget.WidgetNumber(attrs={"style":"width:150px",}),
            "monthly_complete_rate" : widget.WidgetDisabledText(attrs={"style":"width:150px",}),

            "total_sum_money" : widget.WidgetDisabledText(attrs={"style":"width:150px",}),
            "income_target" : widget.WidgetNumber(attrs={"style":"width:150px",}),
            "complete_rate" : widget.WidgetDisabledText(attrs={"style":"width:150px",}),

            "remark" : widget.WidgetTextarea(attrs={"style":"width:380px",})
        }


class PpvDayTotalReportForm(ModelForm):
    def __init__(self,*args,**kwargs):
        super(PpvDayTotalReportForm,self).__init__(*args,**kwargs)

    def custom_valid(self, request, instance, using_db):
        import datetime
        pk = request.REQUEST.get("id", None)
        if pk is None:
            date = datetime.datetime.strptime(request.POST.get("fdate", ""),'%Y-%m-%d').date()
            area = request.POST.get("area", "")
            is_exists = PpvDayTotalReport.objects.using(using_db).filter(
                fdate=date,
                area=area
            ).exists()
            if is_exists:
                return {"message": u"""日期:%s，该地区已经存在,请调整。"""%(date), "code":-1}
        return {"message":"", "code": 0}

    def clean_remark(self):
        is_warning = self.cleaned_data.get("is_warning","")
        remark = self.cleaned_data.get("remark",None)

        if is_warning and not remark:
            raise  forms.ValidationError( u"浮动超过阀值,需输入异常分析" )

        else:
            return self.cleaned_data.get("remark","")


    def save(self, commit=True):
        instance =  super(PpvDayTotalReportForm,self).save()
        instance.coins_percent = decimal.Decimal(instance.p_success_money)  /decimal.Decimal(instance.dis_hall_access_uv) if instance.dis_hall_access_uv else 0
        instance.save()
        return instance


    class Meta:
        model = PpvDayTotalReport
        fields = [
            "id", "fdate","area","product_name","dis_hall_access_uv","c_success_money","p_success_money","coins_percent","remark","is_warning"
        ]
        widgets ={
            "fdate":widget.WidgetDate(attrs={"style":"width:150px",}),
            "product_name":widget.WidgetText(attrs={"style":"width:150px",}),
            "dis_hall_access_uv":widget.WidgetNumber(attrs={"style":"width:150px",}),
            "p_success_money":widget.WidgetNumber(attrs={"style":"width:150px",}),
            "p_success_money":widget.WidgetNumber(attrs={"style":"width:150px",}),
            "coins_percent":widget.WidgetDisabledText(attrs={"style":"width:150px",}),
            "remark" : widget.WidgetTextarea(),
            "is_warning": widget.WidgetSingleSelect(attrs={"style":"width:150px",})
        }

        help_texts = {
            "remark": u"浮动超过阀值,需输入异常分析"
        }


class MonthDayTotalReportForm(ModelForm):
    def __init__(self,*args,**kwargs):
        super(MonthDayTotalReportForm,self).__init__(*args,**kwargs)

    def custom_valid(self, request, instance, using_db):
        import datetime
        pk = request.REQUEST.get("id", None)
        if pk is None:
            date = datetime.datetime.strptime(request.POST.get("fdate", ""),'%Y-%m-%d').date()
            product_name = request.POST.get("product_name", "")
            area = request.POST.get("area", "")
            is_exists = MonthDayTotalReport.objects.using(using_db).filter(
                fdate=date,
                area=area,
                product_name=product_name
            ).exists()
            if is_exists:
                return {"message": u"""日期:%s，该地区已经存在,请调整。"""%(date), "code":-1}

        return {"message":"", "code": 0}

    def clean_remark(self):
        is_warning = self.cleaned_data.get("is_warning","")
        remark = self.cleaned_data.get("remark",None)

        if is_warning and not remark:
            raise  forms.ValidationError( u"浮动超过阀值,需输入异常分析" )

        else:
            return self.cleaned_data.get("remark","")

    def save(self, commit=True):
        instance =  super(MonthDayTotalReportForm,self).save()
        x = (decimal.Decimal(instance.dis_hall_access_uv)-decimal.Decimal(instance.dis_hall_already_order_count))
        instance.c_percent = decimal.Decimal(instance.p_new_add_count)  / x if x else 0
        instance.save()
        return instance

    class Meta:
        model = MonthDayTotalReport
        fields = [
            "id","fdate","area","product_name","p_new_add_count","dis_hall_access_uv","dis_hall_already_order_count","c_percent", "remark","is_warning",
        ]

        widgets ={
                "fdate":widget.WidgetDate(attrs={"style":"width:150px",}),
                "product_name":widget.WidgetText(attrs={"style":"width:150px",}),
                "dis_hall_already_order_count":widget.WidgetNumber(attrs={"style":"width:150px",}),
                "dis_hall_access_uv":widget.WidgetNumber(attrs={"style":"width:150px",}),
                "p_new_add_count":widget.WidgetNumber(attrs={"style":"width:150px",}),
                "c_percent":widget.WidgetDisabledText(attrs={"style":"width:150px",}),
                "remark" : widget.WidgetTextarea(),
                "is_warning": widget.WidgetSingleSelect(attrs={"style":"width:150px",})
            }
        help_texts = {
             "remark": u"浮动超过阀值,需输入异常分析"
        }


class ReceiverConfigForm(ModelForm):
    def __init__(self,*args,**kwargs):
        super(ReceiverConfigForm,self).__init__(*args,**kwargs)

    def clean_report_type(self):
        report_type = self.cleaned_data.get("report_type","")
        if not self.instance.pk: #新增的时候
            is_exists = ReceiverConfig.objects.filter(
                            report_type= report_type
                        ).exists()
            if is_exists:
                raise  forms.ValidationError( u"该报表已经存在" )
        return report_type

    def init_zsjform(self, request, *args, **kwargs):
        from system.models import ReportType
        from base_api import form_fields  as f_field

        using_db = kwargs["using_db"]
        report_type_qs = ReportType.objects.using(using_db).all()

        type_initial = None
        if self.instance:
            type_initial = ReportType.objects.using(using_db).filter(id=self.instance.report_type_id)

        self.fields["report_type"] = f_field.ZsjModelChoiceField(
            queryset=report_type_qs,
            initial=type_initial,
            label=u"报表类型",
            widget=widget.WidgetSingleSelect(attrs={"style": "width:200px"})
        )

    class Meta:
        model = ReceiverConfig
        fields = [
             "user", "report_type","send_type"
        ]

        widgets ={
            "user": widget.WidgetMultipleSelect(attrs={"style": "height:30px;width:200px"}),
            "send_type":widget.WidgetSingleSelect(attrs={"style": "width:200px"})
        }
        label={
            "user":u"接收用户"
        }