# -*- coding: utf-8 -*-
from django.shortcuts import render_to_response
from django.http import HttpResponse
from django.template import RequestContext
from django.shortcuts import render_to_response
import json
from system import utils
from system.models import AreaParams
from base_api import views as base_views

def params_handle(request):
    u"""
        处理添加或编辑
    """
    data = {}
    using_db = request.GET.get("using_db","default")    
    if request.method != "POST":
        id = request.GET.get("id", 0)
        if id > 0:
            data = AreaParams.objects.using(using_db).get(id = id)
        #areas = request.session["user_areas"] 
        from system.models import Area,Params,Type
        types = Type.objects.all()
        areas = Area.objects.all()
        
        params = Params.objects.all()
        return render_to_response("system/params_add.html",{
            "params":params,
            "data" : data,
            "areas":areas,
            "types":types,
        })
    else:
        id = request.POST.get("id", 0)
        if id>0:
            return base_views.edit(request, "system", "AreaParams", id)
        else:
            area_id = request.POST.get("area")
            parms_id = request.POST.get("param")
            from iptv import utils
            if not area_id:
                return utils.show_result("fail", u"请选择地区！")
            if not parms_id:
                return utils.show_result("fail", u"请选择要设置的参数！")
            
            qs =  AreaParams.objects.filter(
                area=area_id,
                param=parms_id
            )
            if qs:
                return utils.show_result("fail", u"该地区已设置改参数,请在原有记录上修改！")
            
            return base_views.create(request, "system", "AreaParams")


@utils.decorate_auth_user("add__system__areaparams")
def areaparams_add(request):
    return params_handle(request)

@utils.decorate_auth_user("modify__system__areaparams")
def areaparams_edit(request):
    return params_handle(request)

     
