# -*- coding: utf-8 -*-
import os
import datetime
import traceback
from system.models import IncomeTotalReport
from system.models import PpvDayTotalReport
from system.models import MonthDayTotalReport
from system.models import ReceiverConfig
from django.conf import settings
from base_api import send_email
import collections
import types
from base_api import views
from django.utils.log import getLogger
logger = getLogger( "default" )

def get_ppv_day_report(month_d,areaid,product_name):
    u"""
    得到某月，某个地区的ppv汇总--每日数据
    """
    head = collections.OrderedDict([
        ["fdate",u"日期"],
        ["area__zname",u"区域名称"],
        ["product_name",u"产品名称"],
        ["dis_hall_access_uv",u"大厅访问uv"],
        ["hall_access_pv",u"大厅访问pv"],
        ["dis_game_start_uv",u"游戏启动uv"],
        ["game_start_pv",u"游戏启动pv"],
        ["p_success_money",u"充值成功总金额"],
        ["p_fail_money",u"充值失败总金额"],
        ["p_success_dis_count",u"充值成功用户数"],
        ["p_total_dis_count",u"充值总用户数"],
        ["p_total_count",u"充值总次数"],
        ["success_percent",u"充值成功率"],
        ["day_new_user",u"大厅新增用户数"],
        ["p_new_add_count",u"新增充值用户数"],
        ["ARPU",u"人均ARPU"],
        ["c_success_money",u"消费成功金额"],
        ["c_fail_money",u"消费失败金额"],
        ["c_total_dis_count",u"消费用户数"],
        ["c_total_count",u"消费次数"],
        ["c_new_add_count",u"新增消费用户数"],
        ["count_month_limit_user",u"消费已达上限用户数"],
        ["month_limit_money",u"月消费限额"],
        ["coins_percent",u"流量转化值"],
        ["daily_pay_percent",u"日付费率"],
        ["total_user",u"历史累计总用户数"],
        ["total_pay_user",u"历史累计付费用户数"],
        ["no_pay_user",u"历史累计从来没有付费的用户数"],
        ["is_warning",u"是否预警"],
        ["remark",u"信息摘要"],
    ])

    #当月明细
    query_set = PpvDayTotalReport.objects.filter(
        area__id = areaid,
        product_name = product_name,
        fdate__year = month_d.year,
        fdate__month = month_d.month,
    ).values(
        *head.keys()
    ).order_by("fdate")

    result=list(query_set)
    result = views.render_rows(result,PpvDayTotalReport)

    #汇总所有行的数据
    total_row = query_set.aggregate(**query_set.model.Admin.aggregate)
    if hasattr(PpvDayTotalReport.Admin,"static_aggregate"):
        static_fields = {}
        for k,v in query_set.model.Admin.static_aggregate.items():
            if type(v) == types.FunctionType:
                static_fields[k] = v(total_row)
            else:
                static_fields[k] = v
        total_row.update(static_fields)

    result.append(total_row)
    return {"head":head,"data":result}


def get_monthly_day_report(month_d,areaid,product_name):
    u"""
    得到某个月，某个地区--包月产品的汇总--每日数据
    """
    head = collections.OrderedDict([
        ["fdate",u"日期"],
        ["area__zname",u"区域名称"],
        ["product_name",u"产品名称"],
        ["dis_hall_access_uv",u"大厅访问用户数"],
        ["hall_access_pv",u"大厅访问次数"],
        ["p_success_dis_count",u"成功订购用户数"],
        ["c_percent",u"转换率"],
        ["dis_order_page_user_uv",u"订购页面访问uv"],
        ["day_new_user",u"大厅新增用户数"],
        ["dis_total_first_login_and_order_user",u"第一次进来并订购的用户数"],
        ["dis_hall_already_order_count",u"已经订购的访问用户"],
        ["success_percent",u"订购成功率"],
        ["p_fail_dis_count",u"失败订购用户数"],
        ["dis_game_start_uv",u"游戏启动uv"],
        ["game_start_pv",u"游戏启动pv"],
        ["p_success_money",u"成功总金额"],
        ["p_fail_money",u"失败总金额"],
        ["p_new_add_count",u"新增订购用户数"],
        ["order_page_user_pv",u"订购页面访问pv"],
        ["total_user",u"历史累计总用户数"],
        ["total_pay_user",u"历史累计订购用户数"],
        ["no_pay_user",u"历史累未订购用户数"],
        ["is_warning",u"是否预警"],
        ["remark",u"信息摘要"],
    ])

    query_set = MonthDayTotalReport.objects.filter(
        area__id = areaid,
        product_name = product_name,
        fdate__year = month_d.year,
        fdate__month = month_d.month,
    ).values(
        *head.keys()
    ).order_by("fdate")

    result = list(query_set)
    result = views.render_rows(result,MonthDayTotalReport)

    #汇总所有行的数据
    total_row = query_set.aggregate(**query_set.model.Admin.aggregate)
    if hasattr(PpvDayTotalReport.Admin,"static_aggregate"):
        static_fields = {}
        for k,v in query_set.model.Admin.static_aggregate.items():
            if type(v) == types.FunctionType:
                static_fields[k] = v(total_row)
            else:
                static_fields[k] = v
        total_row.update(static_fields)

    result.append(total_row)
    return {"head":head,"data":result}


def get_income_total_report(month_d,areaids):
    u"""
    得到某个月截止某一天，收入完成度的报表
    """
    head = collections.OrderedDict([
        ["month",u"月份"],
        ["area__zname",u"区域"],
        ["ppv_sum_money",u"PPV流水(成功)"],
        ["ppv_income_target",u"PPV收入指标"],
        ["ppv_complete_rate",u"PPV完成度"],
        ["month_sum_money",u"包月流水(成功)"],
        ["monthly_income_target",u"包月收入指标"],
        ["monthly_complete_rate",u"包月完成度"],
        ["total_sum_money",u"总流水"],
        ["income_target",u"总收入指标"],
        ["complete_rate",u"总完成度"],
        ["remark",u"信息摘要"],
    ])

    query_set = IncomeTotalReport.objects.filter(
        month__year = month_d.year,
        month__month = month_d.month,
        month__day = month_d.day,
        area__id__in = areaids,
    ).values(
        *head.keys()
    ).order_by("month")

    result = list(query_set)
    result = views.render_rows(result,IncomeTotalReport)

    #汇总所有行的数据
    total_row = query_set.aggregate(**query_set.model.Admin.aggregate)
    if hasattr(PpvDayTotalReport.Admin,"static_aggregate"):
        static_fields = {}
        for k,v in query_set.model.Admin.static_aggregate.items():
            if type(v) == types.FunctionType:
                static_fields[k] = v(total_row)
            else:
                static_fields[k] = v
        total_row.update(static_fields)

    result.append(total_row)
    return {"head":head,"data":result}


def write_data2excel(calculate_date,areaids=None):
    u"""
    @calculate_date ->截止日期
    @areaids ->需要些excel的地区，不填默认为所有地区
    """
    from base_api import utils
    from system.day_report_calculate_3 import get_group_areas
    import xlwt
    SYSTEM_AUTO_CALCULAT = 0 #系统自动统计
    STOP_CALCULATE = "2" #不需要统计的产品

    #因为有些地区的数据，需要合并到某一个地区查看，所以先对地区分组
    group_area_objs = get_group_areas(calculate_pks=areaids,is_need_filter=False)

    #获取所选地区截止当天，当月的数据
    select_areads = [e[0].id for e in group_area_objs]
    total_area_data = get_income_total_report(calculate_date,select_areads)
    all_sheets = collections.OrderedDict()
    all_sheets[u"所有地区汇总报表"] = [total_area_data]

    for  one_group  in group_area_objs:
        #sheet表名称
        sheet_name = u"{areaname}-{month}".format(
            areaname = one_group[0].zname,
            month = calculate_date.strftime("%Y-%m")
        )

        for area_obj in one_group:
            #地区ppv产品处理
            ppv_products = area_obj.product_set.exclude(new_by_hand=STOP_CALCULATE).filter(is_ppv=True)
            for one_pp in ppv_products:
                one_ppv_data = get_ppv_day_report(calculate_date,area_obj.pk,one_pp.c_name)
                one_ppv_data["hidden_fields"] = ["is_warning"]
                one_ppv_data["row_callback"]={"color_coins_percent":get_weekday_style,"color_fdate":get_weekday_style}
                all_sheets.setdefault(sheet_name,[]).append(one_ppv_data)

            #地区包月产品处理
            monthly_products = area_obj.product_set.exclude(new_by_hand=STOP_CALCULATE).filter(is_ppv=False)
            for index,one_mp in enumerate(monthly_products):
                one_monthly_data = get_monthly_day_report(calculate_date,area_obj.pk,one_mp.c_name)
                one_monthly_data["hidden_fields"] = ["is_warning"]
                one_monthly_data["row_callback"]={"color_c_percent":get_weekday_style,"color_fdate":get_weekday_style}
                all_sheets.setdefault(sheet_name,[]).append(one_monthly_data)

    #写入EXCEL
    wk = xlwt.Workbook(encoding="utf-8")
    file_name = u"各地区收入数据报表%s.xls"%calculate_date.strftime("%Y-%m")
    file_path = os.path.join(settings.TEMP_DIR,file_name)
    utils.write_xls2(
        sheets_data=all_sheets,
        flow = file_path,
        wk = wk,
    )
    return file_path


def send_email2user(calculate_date,areaids = None,userids=None):
    u"""
    发送报表给用户
    """
    f = write_data2excel(calculate_date,areaids)
    try:
        users = ReceiverConfig.objects.filter(report_type__c_key="calculte_monthly_report").first().user.all()
    except:
        logger.info("send_email2user areaids=[{areaids}],user_in=[{user_in}], except=[{exp}]".format(
            areaids = areaids,
            user_in = userids,
            exp = traceback.format_exc(),
            )
        )
    else:
        for usr_obj in users:
            if usr_obj.email:
                send_email.package_send_mail(usr_obj.email, u"每日数据报表", u"请看附件",files = [f])
            else:
                logger.info(
                    """
                        send_email2user username=[{username}], email=[{email}] except=[{exp}]
                    """.format(
                        username = usr_obj.username,
                        email = usr_obj.email
                    )
                )


def get_weekday_style(row):
    import xlwt
    fnt = xlwt.Font()
    fnt.name = 'Arial'

    borders = xlwt.Borders()
    borders.left = 1
    borders.right = 1
    borders.top = 1
    borders.bottom = 1

    align = xlwt.Alignment()
    align.horz = xlwt.Alignment.HORZ_CENTER
    align.vert = xlwt.Alignment.VERT_CENTER

#    if row["is_warning"] == 1:
#        fnt.colour_index = xlwt.Style.colour_map['red']

    try:
        d = datetime.datetime.strptime(row["fdate"],"%Y-%m-%d")
        if d.weekday() in(5,6): #星期六，星期日字体显示为红色
            fnt.colour_index = xlwt.Style.colour_map['red']
    except:
        pass
        #logger.info("get_cell_style=except=[%s]"%traceback.format_exc())

    style = xlwt.XFStyle()
    style.font = fnt
    style.borders = borders
    style.alignment = align

    return style
