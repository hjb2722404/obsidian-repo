# -*- coding: utf-8 -*-
import datetime
import traceback
from base_api import django_sql
from system.models import Params
from system.models import MonthProduct
from system.models import MonthProductParams
from system.models import PpvProductParams,Product
import decimal
from django.utils.log import getLogger
logger = getLogger( "default" )

class PpvDayReportCal(object):
    u"PPV日报表"
    def __init__(self,area,current_date = None):
        if not current_date:
            current_date = datetime.datetime.today().date()

        self.current_date = current_date
        self.last_date = self.current_date - datetime.timedelta(days=1)
        self.area = area
        self.using_db = area.zcode
        self.areaname = area.zname
        self.threshold = self.get_threshold()
        self.monthly_products = self.get_area_products()

    def get_area_products(self):
        monthly_products = MonthProduct.objects.filter(
            product__area__id=self.area.pk
        ).values(
            "c_pay_key","c_pv_key","c_table","product__c_name","price"
        )
        return monthly_products

    def get_threshold(self):
        threshold = Params.objects.filter(c_type__c_key="threshold",c_key="ppv_threshold").first()
        return decimal.Decimal(threshold.value)

    def get_ppv_day_report_record(self):

        if self.area.hall_type == "sd":
            product_key = "center"
        else:
            product_key = "center_hd"

        SQL = u"""
            SELECT
              "{areaname}" AS areaname,Q.d AS calculat_date,IFNULL(R.uv,0) AS uv,
               IFNULL(P.ppv_sum_money,0) AS sum_money,IFNULL(P.ppv_sum_money/uv,0) AS rate,
               K.game_uv AS game_uv,IFNULL(P.ppv_sum_money/game_uv,0) AS game_rate
            FROM (
              SELECT '{last_date}' AS d
              UNION
              SELECT '{current_date}'
            ) AS Q
            LEFT JOIN(
              SELECT
                  DATE_FORMAT(c_addtime,'%%Y-%%m-%%d') AS calculat_date,
                  IFNULL(SUM(c_payMoney)/100,0) AS ppv_sum_money
              FROM t_pay_orders t
              WHERE  t.c_addTime BETWEEN '{last_date} 00:00:00' AND '{current_date} 23:59:59' AND c_czstate = 1 
              GROUP BY calculat_date
            ) P ON Q.d = P.calculat_date
            LEFT JOIN(
                SELECT
                    DATE_FORMAT(create_date,'%%Y-%%m-%%d') AS d,COUNT(DISTINCT userid) AS uv
                FROM web_pv.pv_zsjpv
                WHERE create_date BETWEEN "{last_date}" AND "{current_date}"
                AND page_key='main' 
                AND product_key = '{product_key}'
                AND c_class = 'pv'
                AND (c_key is null or c_key="")                
                GROUP BY create_date
            ) R  ON Q.d = R.d
            LEFT JOIN (
                SELECT
                    DATE_FORMAT(IFNULL(create_date,''),'%%Y-%%m-%%d') as d,
                    count(DISTINCT userid) as game_uv
                FROM
                web_pv.pv_zsjpv
                WHERE create_date BETWEEN "{last_date}" AND "{current_date}"
                    AND product_key='{product_key}'
                    AND right(page_key,6) ='_start'
                GROUP BY  create_date WITH ROLLUP
            )K ON Q.d = K.d
            ORDER BY Q.d ASC
        """.format(
            areaname = self.areaname,
            last_date = self.last_date.strftime("%Y-%m-%d"),
            current_date = self.current_date.strftime("%Y-%m-%d"),
            product_key = product_key
        )
        
        two_days_record = list(django_sql.DJRawQuerySet(
            SQL,
            using=self.using_db
        ))

        last_obj = two_days_record[0] #昨天的数据
        current_obj = two_days_record[1] #今天的数据

        # 湖北电信,四川电信特殊处理
        if self.area.zcode in "90014,90021":
            current_obj["uv"] = current_obj["game_uv"]
            current_obj["rate"] = current_obj["game_rate"]
        del current_obj["game_uv"]
        del current_obj["game_rate"]

        is_warning = False
        if abs((current_obj["rate"] or 0) - (last_obj["rate"] or 0)) >self.threshold:
            is_warning = True

        current_obj.update({"is_warning":is_warning})
        return current_obj


class MonthlyDayReportCal(object):
    u"包月日报表"
    def __init__(self,area,current_date = None):
        if not current_date:
            current_date = datetime.datetime.today().date()

        self.current_date = current_date
        self.last_date = self.current_date - datetime.timedelta(days=1)
        self.area = area
        self.area_id = area.id
        self.using_db = area.zcode
        self.areaname = area.zname
        self.threshold = self.get_threshold()
        self.monthly_products = self.get_area_products()

    def get_area_products(self):
        monthly_products = MonthProduct.objects.filter(
            product__area__id=self.area.pk
        ).values(
            "c_pay_key","c_pv_key","c_table","product__c_name","price"
        )
        return monthly_products

    def get_threshold(self):
        threshold = Params.objects.filter(c_type__c_key="threshold",c_key="month_threshold").first()
        return decimal.Decimal(threshold.value)

    def get_monthly_day_report_record(self):
        monthly_pay_filter = ""
        monthly_pv_filter = ""
        pay_table = "t_month_pay_order"

        if self.monthly_products:
            monthly_pay_filter = "AND c_product IN  (%s)" % (",".join(["'%s'"%obj["c_pay_key"] for obj in self.monthly_products]))
            monthly_pv_filter = "AND product_key IN (%s)" % (",".join(["'%s'" % obj["c_pv_key"].replace('', "").replace( ',', "','") for obj in self.monthly_products]))
            pay_table = self.monthly_products[0]["c_table"] #地区的包月记录表要一样
        
        P_SQL = u"""
            SELECT
                '{areaname}' AS areaname,
                Q.product_name,
                Q.d AS calculat_date,
                c_pay_key,
                c_pv_key
            FROM
                (
                    SELECT
                        '{last_date}' AS d,
                        c_name AS product_name,
                        c_pay_key,
                        c_pv_key
                    FROM
                        system_monthproduct t
                    LEFT JOIN system_product p ON p.id = t.product_id
                    WHERE
                        p.area_id = {area_id}
                    UNION
                        SELECT
                            '{current_date}' AS d,
                            c_name AS product_name,
                            c_pay_key,
                            c_pv_key
                        FROM
                            system_monthproduct t
                        LEFT JOIN system_product p ON p.id = t.product_id
                        WHERE
                            p.area_id = {area_id}
                ) AS Q
            ORDER BY
                Q.d,
                Q.product_name ASC

        """.format(
            area_id = self.area_id,
            areaname = self.areaname,
            last_date = self.last_date.strftime("%Y-%m-%d"),
            current_date = self.current_date.strftime("%Y-%m-%d"),
        )
        
        monthproduct_data = list(django_sql.DJRawQuerySet(
                    P_SQL,
                    using="default"
                ))
        
        SQL = u"""
                SELECT
                    IFNULL(P.d,0) AS d,IFNULL(P.c_product,0) AS pay_key ,
                    IFNULL(P.day_order_number, 0) AS day_order_number
                FROM
                (
                    SELECT
                        DATE_FORMAT(c_addtime, '%%Y-%%m-%%d') AS d,
                        COUNT(DISTINCT c_userid) AS day_order_number,
                        c_product
                    FROM
                        {pay_table} t
                    WHERE
                        t.c_addTime BETWEEN '{last_date} 00:00:00'
                    AND '{current_date} 23:59:59'
                    AND c_czstate = 1
                    {monthly_pay_filter}
                    GROUP BY d, c_product
                ) P        
        """.format(
            last_date = self.last_date.strftime("%Y-%m-%d"),
            current_date = self.current_date.strftime("%Y-%m-%d"),
            monthly_pay_filter  =  monthly_pay_filter,
            pay_table = pay_table
        )

        pay_data = list(django_sql.DJRawQuerySet(
                    SQL,
                    using=self.using_db
                ))
                                
        SQL = u"""
            SELECT
                R.d AS d,R.product_key AS pv_key,
                IFNULL(R.uv, 0) AS uv
            FROM
            (
                SELECT
                    create_date AS d,
                    COUNT(DISTINCT userid) AS uv,
                    product_key
                FROM
                    web_pv.pv_zsjpv
                WHERE
                    create_date BETWEEN "{last_date}"
                AND "{current_date}"
                {monthly_pv_filter}
                GROUP BY create_date, product_key
            ) R

        """.format(
            last_date = self.last_date.strftime("%Y-%m-%d"),
            current_date = self.current_date.strftime("%Y-%m-%d"),
            monthly_pv_filter = monthly_pv_filter,
        )

        pv_data = list(django_sql.DJRawQuerySet(
                    SQL,
                    using=self.using_db
                ))      
        
        ## 配置完所有的数据
        current_obj = []
        rate_dict = {}
        for i, v in enumerate(monthproduct_data):
            
            # 添加订购用户数
            v["day_order_number"] = 0
            for elem in pay_data:
                if v["c_pay_key"] == elem["pay_key"] and v["calculat_date"] == elem["d"]:
                    v["day_order_number"] = elem["day_order_number"]
            
            # 添加UV，计算转化值
            v["rate"] = 0
            v["uv"] = 0
            for elem in pv_data: ## 广东电信 的PV键值：month_hall_hd, month_hall
                if elem["pv_key"] in v["c_pv_key"] and v["calculat_date"] == elem["d"]:
                    v["uv"] = v["uv"] + elem["uv"]

            if v["uv"] > 0 :
                v["rate"] = float(v["day_order_number"])/float(v["uv"])
            
            # 判断是否警告字段
            v["is_warning"] = False
            key = "%s-%s"%(v["c_pv_key"], v["calculat_date"])
            if rate_dict and key in rate_dict.keys():
                if abs((rate_dict[key] or 0) - (v["rate"] or 0)) >self.threshold:
                    v["is_warning"] = True
            else:
                rate_dict[key] = v["rate"]
            
            # 删除无用的key
            del v["c_pay_key"]
            del v["c_pv_key"]
            if v["calculat_date"] == self.current_date.strftime("%Y-%m-%d"):
                current_obj.append(v)

        return current_obj

class TotalMonthReportCal(object):
    u"汇总月报表"

    def __init__(self,area,current_date = None):
        if not current_date:
            current_date = datetime.datetime.today().date()

        self.current_date = current_date
        self.area = area
        self.using_db = area.zcode
        self.areaname = area.zname
        self.monthly_products = self.get_area_monthly_products()
        self.ppv_produts = self.get_area_ppv_produts()

    def get_area_monthly_products(self):
        u"得到当月所配置的产品参数"
        monthly_products = MonthProductParams.objects.filter(
            product__product__area__id = self.area.id,
            month__year = self.current_date.year,
            month__month = self.current_date.month,
        ).values(
            "product__c_pay_key","product__c_pv_key","product__c_table",
            "product__product__c_name","product__price","continue_subscribe_numbers",
            "income_target"
        )
        return monthly_products

    def get_area_ppv_produts(self):
        ppv_produts = PpvProductParams.objects.filter(
            product__area__id = self.area.id,
            month__year = self.current_date.year,
            month__month = self.current_date.month,
        ).values(
            "product__c_name","income_target"
        ).first()
        return ppv_produts

    def get_ppv_sum_money(self):
        u"得到当月ppv总金额"
        monthly_pay_filter = ""
        if self.monthly_products:
            monthly_pay_filter = "AND c_product NOT IN  (%s)"%(",".join(["'%s'"%obj["product__c_pay_key"] for obj in self.monthly_products]))

        SQL = u"""
            SELECT
                IFNULL(SUM(c_payMoney)/100,0) AS ppv_sum_money
            FROM t_pay_orders t
            WHERE DATE_FORMAT(t.c_addTime,"%%Y-%%m-%%d") BETWEEN '{first_day}' AND '{current_date}'
            AND c_czState = 1
            {monthly_pay_filter}
        """.format(
            first_day = self.current_date.strftime('%Y-%m-01'),
            current_date = self.current_date.strftime("%Y-%m-%d"),
            monthly_pay_filter = monthly_pay_filter
        )

        result = list(django_sql.DJRawQuerySet(
            SQL,
            using=self.using_db
        ))

        return {
            "sum_money":result[0]["ppv_sum_money"],
            "income_target":self.ppv_produts["income_target"] if self.ppv_produts else 0,
            "remark":"",
        }

    def get_monthly_sum_money(self):
        u"""
            得到当月汇总金额，每月配置表中续订总金额+当月新增总金额
        """
        remark = []
        total_money_for_current_month = 0
        total_income_target = 0 #每个产品的收入指标

        #当月新增的订购总额
        table = "t_month_pay_order"
        monthly_pay_filter = ""

        if self.monthly_products:
            table = self.monthly_products[0]["product__c_table"]
            monthly_pay_filter = "AND c_product IN  (%s)"%(",".join(["'%s'"%obj["product__c_pay_key"] for obj in self.monthly_products]))

        SQL = u"""
            SELECT
                c_product, IFNULL(SUM(c_payMoney)/100,0) AS c_payMoney
            FROM {table} t
            WHERE  DATE_FORMAT(t.c_addTime,"%%Y-%%m-%%d") BETWEEN '{first_day}' AND  '{current_date}'
            AND c_czState = 1 
            {monthly_pay_filter}
            GROUP BY c_product
        """.format(
            table = table,
            first_day = self.current_date.strftime('%Y-%m-01'),
            current_date = self.current_date.strftime("%Y-%m-%d"),
            monthly_pay_filter =monthly_pay_filter
        )
        
        result = list(django_sql.DJRawQuerySet(
            SQL,
            using=self.using_db
        ))
        
        sum_money = 0
        new_money = {}
        for i,v in enumerate(result):
            sum_money = sum_money + v["c_payMoney"]
            new_money[v["c_product"]] = v["c_payMoney"]
              
        for p in self.monthly_products:
            price = p["product__price"]
            numbers = p["continue_subscribe_numbers"]
            p_income_target = p["income_target"]
            pay_key = p["product__c_pay_key"]
            product_money = price * numbers

            if pay_key in new_money.keys():
                product_money = product_money + new_money[pay_key]
                 
            remark.append(u"产品名称：{pname}，续订用户数：{subscribe_numbers},该产品总额：{product_money}".format(
                pname = p["product__product__c_name"],
                subscribe_numbers = numbers,
                product_money = product_money
            ))
            
            total_income_target = total_income_target + p_income_target
            total_money_for_current_month  = total_money_for_current_month + product_money

            
        return {
            "income_target":total_income_target,
            "sum_money":total_money_for_current_month,
            "remark":u";".join(remark),
            }


    def get_current_month_report_record(self):
        ppv_obj = self.get_ppv_sum_money()
        monthly_obj = self.get_monthly_sum_money()

        result =  {
            "month":self.current_date,
            "areaname":self.areaname,
            "ppv_sum_money":ppv_obj["sum_money"],
            "month_sum_money": monthly_obj["sum_money"],
            "total_sum_money":ppv_obj["sum_money"] + monthly_obj["sum_money"],
            "income_target":ppv_obj["income_target"] + monthly_obj["income_target"],
            "remark":ppv_obj["remark"]+monthly_obj["remark"],
        }
        if result["income_target"]:
            result["complete_rate"] = result["total_sum_money"] / result["income_target"]
        return result


def save_ppv_day_data(calculate_date,areas = None):
    from system.models import Area
    from system.models import  PpvDayTotalReport

    if not areas:
        zcodes = Product.objects.filter(is_ppv=1).values_list("area__zcode")
        areas = Area.objects.filter(zcode__in=zcodes )
    
        for area_obj in areas:
            try:
                #保存ppv数据
                ppv_record = PpvDayReportCal(area_obj,current_date=calculate_date).get_ppv_day_report_record()
                is_exists = PpvDayTotalReport.objects.filter(calculat_date=ppv_record["calculat_date"],areaname = ppv_record["areaname"])

                if not is_exists:
                    PpvDayTotalReport(**ppv_record).save()
                else:
                    PpvDayTotalReport.objects.filter(calculat_date=ppv_record["calculat_date"], areaname = ppv_record["areaname"]).update(**ppv_record)

            except:
                # print traceback.format_exc()
                logger.info(u"zcode=%s,areaname = %s,%s" %(area_obj.zcode,area_obj.zname,traceback.format_exc()))
                continue                

def save_monthly_day_data(calculate_date,areas = None):
    #保存包月的数据
    from system.models import Area
    from system.models import MonthDayTotalReport
    if not areas:
        zcodes = Product.objects.filter(is_ppv=0).values_list("area__zcode")
        areas = Area.objects.filter(zcode__in = zcodes)

    for area_obj in areas:
        try:
            monthly_records = MonthlyDayReportCal(area_obj,current_date=calculate_date).get_monthly_day_report_record()
            for  monthly_record in monthly_records:
                is_exists = MonthDayTotalReport.objects.filter(
                    product_name=monthly_record["product_name"],calculat_date=monthly_record["calculat_date"],
                    areaname=monthly_record["areaname"]).exists()
                if not is_exists:
                    MonthDayTotalReport(**monthly_record).save()
                else:
                    MonthDayTotalReport.objects.filter( product_name=monthly_record["product_name"],
                                                        calculat_date=monthly_record["calculat_date"],
                                                        areaname=monthly_record["areaname"]).update(**monthly_record)
        except:
            # print traceback.format_exc()
            logger.info(u"zcode=%s,areaname = %s,%s" %(area_obj.zcode,area_obj.zname,traceback.format_exc()))
            continue   
            
def save_monthly_month_data(calculate_date,areas = None):
    u"""
    保存包月月报表
    """
    from system.models import Area
    from system.models import IncomeTotalReport

    if not areas:
        zcodes = Product.objects.values_list("area__zcode")
        areas = Area.objects.filter(zcode__in = zcodes)

    #保存每月汇总数据
    for elem in areas:
        try:
            record = TotalMonthReportCal(elem, current_date=calculate_date).get_current_month_report_record()
            is_exists = IncomeTotalReport.objects.filter(
                month=record["month"],
                areaname=record["areaname"]
            ).exists()

            if u"新疆电信" in elem.zname or u"新疆广电" in elem.zname:
                area_datas = IncomeTotalReport.objects.filter(
                    month=record["month"],
                    areaname__contains=elem.zname[:4]
                )
                if area_datas.exists():
                    area_data = area_datas[0]
                    ppv_sum_money = area_data.ppv_sum_money+record["ppv_sum_money"]
                    month_sum_money = area_data.month_sum_money+record["month_sum_money"]
                    total_sum_money = area_data.total_sum_money+record["total_sum_money"]
                    income_target = area_data.income_target+record["income_target"]
                    remark = "%s;%s"%(area_data.remark, record["remark"])
                    IncomeTotalReport.objects.filter(month=record["month"], areaname__contains = elem.zname[:4]).update(
                        ppv_sum_money = ppv_sum_money,
                        month_sum_money = month_sum_money,
                        total_sum_money = total_sum_money,
                        income_target = income_target,
                        complete_rate = float(income_target)/float(total_sum_money),
                        remark = remark
                    )
                else:
                    if not is_exists:
                        IncomeTotalReport(**record).save()
            else:
                if not is_exists:
                    IncomeTotalReport(**record).save()
                else:
                    IncomeTotalReport.objects.filter(
                                    month=record["month"],
                                    areaname=record["areaname"]
                    ).update(**record)
        except:
            # print traceback.format_exc()
            logger.info(u"zcode=%s,areaname = %s,%s" %(elem.zcode,elem.zname,traceback.format_exc()))
            continue
            
        

