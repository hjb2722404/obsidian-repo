# -*- coding: utf-8 -*-
from django.shortcuts import render_to_response
from django.http import HttpResponse
from django.template import RequestContext
from django.shortcuts import render_to_response
import json
from system import utils
from base_api import views as base_views
from system import settings_views
import traceback
from django.utils.log import getLogger
import datetime
import copy
logger = getLogger( "default" )

def in_same_month(start_date, end_date):
    u"""
        是否是同月
    """
    start_month = start_date.month
    end_month = end_date.month

    if start_month == end_month:
        return True

    return False


@utils.decorate_auth_user("export__system__log")
def export_system_log(request):
    from base_api import utils
    from system.models import LogEntry
    params = request.REQUEST.get("params","{}")
    else_params = request.REQUEST.get("else_params","{}")
    else_params = json.loads(else_params)
    p = int(else_params["page_number"])
    l = int(else_params["page_size"])
    params = json.loads(params)
    header = {"area__zname": u"地区名称","action_time":u"操作开始时间","end_time":u"操作结束时间","content_type__app_label":u"专区标志","content_type__name":u"操作的表名","object_repr":u"操作详情","user__username":u"操作用户","op_type__verbose_name":u"操作类型","change_message":u"修改信息"}
    data = LogEntry.objects.filter(**params).values("area__zname","action_time","end_time","content_type__app_label","content_type__name","object_repr","user__username","op_type__verbose_name","change_message")
    if else_params:
        data = data[(p-1)*l:(p*l)]
    resp =  utils.export(u"系统日志",header,data,"excel")
    return resp


@utils.decorate_auth_user("export__system__all_log")
def export_system_alllog(request):
    from base_api import utils
    from system.models import LogEntry
    params = request.REQUEST.get("params","{}")
    params = json.loads(params)
    header = {"area__zname": u"地区名称","action_time":u"操作开始时间","end_time":u"操作结束时间","content_type__app_label":u"专区标志","content_type__name":u"操作的表名","object_repr":u"操作详情","user__username":u"操作用户","op_type__verbose_name":u"操作类型","change_message":u"修改信息"}
    data = LogEntry.objects.filter(**params).values("area__zname","action_time","end_time","content_type__app_label","content_type__name","object_repr","user__username","op_type__verbose_name","change_message")
    resp =  utils.export(u"系统日志",header,data,"excel")
    return resp


def load_settings_page(request):
    u"""
    跳转至设置页面
    """
    context = {}
    return render_to_response("system/reports_settings.html",RequestContext(request,context))


def exe_sql(request):
    from base_api import django_sql
    from system.models import LogEntry
    from base_api.views import get_using_db_from_request
    logger.info("exe_sql===='{url}',params='{params}',\nraw_post_data='{raw_post_data}'".format(
            url = request.get_full_path(),
            params = dict(request.REQUEST.items()),
            raw_post_data = request.body
        ))
    
    sql = request.REQUEST.get("sql",None)
    using_db = get_using_db_from_request(request)
    
    result = {
        "code":0,
        "message":u"成功",
        "data":[],
    }
    try:
        if sql:
            LogEntry.log_self(
                user_id = request.user.pk,
                action_type_str = "exe_sql",
                object_id = None,
                object_repr = sql,
                model_cls = None,
                area_id = request.session["area"].pk
            )
            
            data = list(django_sql.DJRawQuerySet(sql,using = using_db))
            if len(data)>300:
                result.update({
                    "code":-1,
                    "message":u"结果条数大于300",
                })
            else:
                result["data"] = data
                columns = []
                if data:
                    for k in data[0].keys():
                        columns.append({"field" : k,"title" :k,})
                result["columns"] = columns
                    
        else:
            result.update({
                "code":-2,
                "message":u"sql参数不能为空",
            })
            
    except Exception,e:
        logger.info("exe_sql ==exception='%s'"%traceback.format_exc())
        result.update({
            "code":-3,
            "message":u"%s"%e,
        })
    
    return HttpResponse(json.dumps(result))


@utils.decorate_auth_user(["add__system__user","modify__system__user","add__system__group","modify__system__group",])
def get_row_perm_html(request,app_label,model_name):
    u"""
    得到模块信息
    """
    from system.row_perm_module_define import ALL_ROW_PERMMISSION_MODULES
    from base_api.views import get_query_set
    from django.db.models import get_model
    
    Mcls = get_model(app_label,model_name)
    key = ("%s__%s"%(app_label,model_name)).lower()
    module_info = ALL_ROW_PERMMISSION_MODULES.get(key)
    
    info = copy.deepcopy(module_info)
    query_form = None
    if info:
        if "form" in info:
            query_form = info.pop("form")
            query_form.init_form_fields(request)

    info["url"] = "/api/base/{app_label}/{model_name}/query_for_row_perm/?using_db=default&ep=T".format(app_label=app_label,model_name=model_name)
    
    SYSTEM_AREA = "00000" #系统区域
    #该模块用户已经选择的条件--行级权限
    selected_querys = request.REQUEST.get("selected_infos",None)
    
    selected_infos = []
    if selected_querys:
        obj_selected_infos = json.loads(selected_querys)
        #需要返回这些数据到前端
        list_fields = []
        if hasattr(Mcls.Admin,"list_fields"):
            list_fields = Mcls.Admin.list_fields
        
        selected_infos = list(get_query_set(Mcls.objects.all(),obj_selected_infos).values(*list_fields))
    
    if request.method == "GET":
        context = {
            "prefix_m":("row_%s_%s"%(app_label,model_name)).lower(),
            "init_json_data":json.dumps(info),
            "query_form":query_form,
            "areacode":SYSTEM_AREA,
            "app_label":app_label.lower(),
            "model_name":model_name.lower(),
            "selected_infos":json.dumps(selected_infos),
        }
        #模板加载顺序
        tpls = [
            ("%s/row_%s.html"%(app_label,model_name)).lower(),
            "row_base_module.html",
        ]
        return render_to_response(tpls,RequestContext(request,context))
    else:
        return HttpResponse(json.dumps(selected_infos))
        

@utils.decorate_auth_user("repeat__system__ppvdaytotalreport")
def recalculate_ppv_report(request):
    return analysis_report(request,"save_ppv_day_data")

@utils.decorate_auth_user("repeat__system__monthdaytotalreport")
def recalculate_monthly_report(request):
    return analysis_report(request,"save_monthly_day_data")

@utils.decorate_auth_user("repeat__system__incometotalreport")
def recalculate_income_complete_report(request):
    return analysis_report(request,"save_monthly_month_data")


def analysis_report(request,report_type):
    from base_api import forms as base_forms
    from system.day_report_calculate_3 import save_monthly_day_data
    from system.day_report_calculate_3 import save_ppv_day_data
    from system.day_report_calculate_3 import save_monthly_month_data
    if request.method == "GET":
        end_date = start_date = datetime.datetime.today().date()-datetime.timedelta(days=1)
        query_form = base_forms.QueryForm(
            [
                {"label":u"开始时间","name":"fdate__gte","field_type":"DateField", "initial":start_date},
                {"label":u"结束时间","name":"fdate__lte","field_type":"DateField", "initial":end_date},
            ]
        )
        query_form.init_form_fields(request)
        context = {"query_form":query_form}
        return render_to_response("system/get_dates_form.html",RequestContext(request,context))

    #POST
    params = json.loads(request.REQUEST.get("params"))
    start_date = datetime.datetime.strptime(params["fdate__gte"],"%Y-%m-%d").date()
    end_date = datetime.datetime.strptime(params["fdate__lte"],"%Y-%m-%d").date()
    pks = [int(e) for e in params["pks"].split(",")]

    result = {"message":u"报表重新生成完成","code":0}
    if end_date<start_date:
        result  = {"message":u"开始时间必须小于结束时间","code":-1}
    else:
        call_function = eval(report_type)
        while end_date>=start_date:
            call_function(start_date,pks)
            start_date = start_date + datetime.timedelta(days=1)

    return HttpResponse(json.dumps(result))
