# -*- coding: utf-8 -*-
import datetime
import traceback
from system.models import Params
from base_api import django_sql
from system.models import PpvProduct
from system.models import MonthProduct
from system.models import PpvDayTotalReport
from system.models import MonthDayTotalReport
import decimal
from base_api import utils
from django.utils.log import getLogger
logger = getLogger( "default" )

class PpvDayReportCal(object):
    u"PPV日报表"
    def __init__(self,ppv_product,current_date,using_db):
        self.current_date = current_date
        self.last_date = current_date - datetime.timedelta(days =1)
        self.areaid = ppv_product["product__area__id"]
        self.product_name = ppv_product["product__c_name"]
        self.using_db = using_db
        self.threshold = self.get_threshold()
        self.product_obj = ppv_product
        self.exclude_month_pay_keys = self.get_area_exclude_month_pay_keys()

    def get_threshold(self):
        u"获取警告阀值"
        threshold = Params.objects.filter(c_type__c_key="threshold",c_key="ppv_threshold").first()
        return decimal.Decimal(threshold.value)

    def check_is_warning(self,current_obj):
        u"判断是否要警告，通过当前的值与前一天的值比较"
        is_warning = False
        #前一天的数据
        last_obj = PpvDayTotalReport.objects.filter(
            fdate=self.last_date,
            area_id=self.areaid,
            product_name = self.product_name,
            ).values("coins_percent").first()

        if last_obj:
            #前一天和当天的数据比较超过阀值
            if abs(decimal.Decimal(current_obj["coins_percent"] or 0) - (last_obj["coins_percent"] or 0)) >self.threshold:
                is_warning = True

        return is_warning

    def get_area_exclude_month_pay_keys(self):
        u"""
        得到该地区的包月类型产品的支付键值
        """
        exclude_month_pay_keys = list(MonthProduct.objects.filter(
            product__area__id=self.areaid,
            c_table = "t_pay_orders"
        ).values_list("c_pay_key",flat=True))

        return exclude_month_pay_keys


    def get_ppv_day_report_record(self):
        u"""
        获取ppv一天的数据
        """
        params = {
            "using_db":self.using_db,
            "start_time":self.current_date,
            "end_time":self.current_date,
            "pv_keys":self.product_obj["c_pv_key"].split(","),
            "limit_money":self.product_obj["limit_money"],
            "exclude_month_pay_keys":self.exclude_month_pay_keys,
            "is_ott":self.product_obj["is_ott"],
        }

        logger.info("PpvDayReportCal->get_ppv_day_report_record  params='%s'"%params)
        two_days_record = list(utils.report_api_request("AppReportsRemote","day_report",params))
        logger.info("PpvDayReportCal->get_ppv_day_report_record return='%s'"%two_days_record)

        #取结果中的当天数据，汇总的那条数据不要
        current_obj = two_days_record[0] #今天的数据

        is_warning = self.check_is_warning(current_obj)
        current_obj.update({"is_warning":is_warning,"area_id":self.areaid,"product_name":self.product_name})
        return current_obj


class MonthlyDayReportCal(object):
    u"包月日报表"
    def __init__(self,product_obj,current_date,using_db):
        self.current_date = current_date
        self.last_date = self.current_date - datetime.timedelta(days=1)
        self.product_obj = product_obj
        self.using_db = using_db
        self.threshold = self.get_threshold()

    def check_is_warning(self,current_obj):
        u"判断是否要警告，通过当前的值与前一天的值比较"
        is_warning = False
        #前一天的数据
        last_obj = MonthDayTotalReport.objects.filter(
            fdate=self.last_date,
            area_id=self.product_obj["product__area__id"],
            product_name = self.product_obj["product__c_name"],
            ).values("c_percent").first()

        if last_obj:
            #前一天和当天的数据比较超过阀值
            if abs(decimal.Decimal(current_obj["c_percent"] or 0) - (last_obj["c_percent"] or 0)) >self.threshold:
                is_warning = True

        return is_warning

    def get_threshold(self):
        threshold = Params.objects.filter(c_type__c_key="threshold",c_key="month_threshold").first()
        return decimal.Decimal(threshold.value)

    def get_monthly_day_report_record(self):
        u"获取包月一天的数据"
        params = {
            "using_db":self.using_db,
            "start_time":self.current_date,
            "end_time":self.current_date,
            "pv_keys":self.product_obj["c_pv_key"].split(","),
            "pay_keys":self.product_obj["c_pay_key"].split(","),
            "table":self.product_obj["c_table"],
            "ratio":self.product_obj["ratio"],
            }

        if self.using_db == "gd_topway":#深圳天威
            logger.info("request ReportsRemote->month_report_topway params='%s'"%params)
            two_days_record = list(utils.report_api_request("AppReportsRemote","month_report_topway",params))
            logger.info("request ReportsRemote->month_report_topway return='%s'"%two_days_record)
        else:
            logger.info("PpvDayReportCal->get_monthly_day_report_record  params='%s'"%params)
            two_days_record =  list(utils.report_api_request("AppReportsRemote","month_report",params))
            logger.info("PpvDayReportCal->get_monthly_day_report_record return='%s'"%two_days_record)

        #取结果中的当天数据，汇总的那条数据不要
        current_obj = two_days_record[0] #今天的数据

        is_warning = self.check_is_warning(current_obj)
        current_obj.update({
            "is_warning":is_warning,
            "area_id":self.product_obj["product__area__id"],
            "product_name":self.product_obj["product__c_name"]
        })
        return current_obj


class TotalMonthReportCal(object):
    u"汇总月报表"
    def __init__(self,area,merge_areaids,current_date):
        self.current_date = current_date
        self.area = area
        self.merge_areaids = merge_areaids

    def get_current_month_all_product_sum_money(self):
        u"得到一个地区所有产品的汇总列表"
        CALCULATE_WITH_CONSUME = { #通过消费计算总额的地区
            "80035":u"深圳天威",
        }
        column_for_calculate = "p_success_money"
        if self.area.zcode in CALCULATE_WITH_CONSUME:
            column_for_calculate = "c_success_money"

        sql = u"""
                SELECT
                    area_id,
                    c_name,
                    product_id,
                    is_ppv,
                    m,
                    IFNULL(s_money,0) AS s_money,
                    IFNULL(subscribe_money,0) AS subscribe_money,
                    IFNULL(income_target,0) AS income_target
                FROM
                (
                    (
                        SELECT C.*,(D.subscribe_money+C.day_subscribe_money) AS subscribe_money,D.income_target FROM (
                                SELECT
                                    tb_r.area_id,
                                    tb_p.c_name,
                                    tb_p.id AS product_id,
                                    tb_p.is_ppv,
                                    date_format(fdate,"%%Y-%%m") AS m,
                                    SUM(tb_r.{column_for_calculate}) AS s_money,
                                    0 AS day_subscribe_money
                                FROM system_ppvdaytotalreport tb_r,system_product tb_p
                                WHERE
                                    tb_r.area_id = tb_p.area_id
                                    AND
                                    tb_r.product_name = tb_p.c_name
                                    AND
                                    date_format(fdate,"%%Y-%%m") = "{month}"
                                    AND 
                                    date_format(fdate,"%%Y-%%m-%%d") <= "{current_date}"
                                    AND
                                    tb_r.area_id in {merge_areaids}
                                GROUP BY tb_r.area_id,tb_p.c_name,tb_p.id,tb_p.is_ppv,m
                        ) C
                        LEFT JOIN(
                            SELECT
                                t2.product_id,0 AS subscribe_money,t1.income_target
                            FROM  system_ppvproductparams t1,system_ppvproduct  t2
                            WHERE
                                DATE_FORMAT(t1.month,"%%Y-%%m") ="{month}"
                                AND
                                t1.product_id= t2.id
                        ) D
                        ON C.product_id = D.product_id
                    )
                    UNION
                    (
                        SELECT A.*,(B.subscribe_money+A.day_subscribe_money) AS subscribe_money,B.income_target FROM(
                            SELECT
                                tb_r.area_id,
                                tb_p.c_name,
                                tb_p.id AS product_id,
                                tb_p.is_ppv,
                                date_format(fdate,"%%Y-%%m") AS m,
                                SUM(tb_r.p_success_money) AS s_money,
                                SUM(p_subscribe_success_money) AS day_subscribe_money
                            FROM system_monthdaytotalreport tb_r,system_product tb_p
                            WHERE
                                tb_r.area_id = tb_p.area_id
                                AND
                                tb_r.product_name = tb_p.c_name
                                AND
                                date_format(fdate,"%%Y-%%m") = "{month}"
                                AND 
                                date_format(fdate,"%%Y-%%m-%%d") <= "{current_date}"
                                AND
                                tb_r.area_id in {merge_areaids}
                            GROUP BY tb_r.area_id,tb_p.c_name,tb_p.id ,tb_p.is_ppv,m
                         ) A
                        LEFT JOIN(
                            SELECT
                                t2.product_id,t1.continue_subscribe_numbers*t2.price AS subscribe_money,t1.income_target
                            FROM  system_monthproductparams t1,system_monthproduct  t2
                            WHERE
                                DATE_FORMAT(month,"%%Y-%%m") ="{month}"
                                AND
                                t1.product_id= t2.id
                        ) B
                        ON  B.product_id = A.product_id
                    )
                 ) W
        """.format(
            merge_areaids ="("+ u",".join(["%s"%uid for uid in self.merge_areaids]) + ")",
            month = self.current_date.strftime("%Y-%m"),
            current_date = self.current_date.strftime("%Y-%m-%d"),
            column_for_calculate = column_for_calculate,
        )

        all_product_detail = list(django_sql.DJRawQuerySet(
            sql,
            using="default"
        ))
        return all_product_detail


    def get_current_month_report_record(self):
        u"""
        汇总,截止当天，本月所有数据情况
        """
        all_detail_products = self.get_current_month_all_product_sum_money()
        ppv_income_target_items = [] #ppv总目标
        monthly_income_target_items = [] #包月总目标
        ppv_sum_money_items = []
        monthly_sum_money_items = []
        remark = []

        for elem in all_detail_products:
            if elem["is_ppv"]:
                ppv_sum_money_items.append(elem["s_money"]) #截止当天，当月总收入
                ppv_income_target_items.append(elem["income_target"]) #ppv产品当月目标
                remark.append(u"PPV产品:[{product_name}],目标:[{income_target}],收入:[{s_money}];".format(
                    product_name = elem["c_name"],
                    income_target = elem["income_target"],
                    s_money = elem["s_money"],
                ))
            else:
                monthly_sum_money_items.append(elem["s_money"]) #截止当天，当月总收入
                monthly_sum_money_items.append(elem["subscribe_money"]) #续订金额
                monthly_income_target_items.append(elem["income_target"]) #包月产品当月目标
                remark.append(u"包月产品:[{product_name}],目标:[{income_target}],续订总额:[{subscribe_money}],收入:[{s_money}];".format(
                    product_name = elem["c_name"],
                    income_target = elem["income_target"],
                    subscribe_money = elem["subscribe_money"],
                    s_money = elem["s_money"],
                ))

        total_ppv_sum_money = sum(ppv_sum_money_items) #ppv汇总
        total_ppv_income_target = sum(ppv_income_target_items) #ppv总目标
        total_monthly_sum_money = sum(monthly_sum_money_items) #包月汇总
        total_monthly_income_target = sum(monthly_income_target_items) #包月总目标

        result =  {
            "month":self.current_date,
            "area_id":self.area.id,
            "ppv_sum_money":total_ppv_sum_money,
            "ppv_income_target":total_ppv_income_target,
            "month_sum_money": total_monthly_sum_money,
            "monthly_income_target":total_monthly_income_target,
            "total_sum_money":total_ppv_sum_money+total_monthly_sum_money,
            "income_target":total_ppv_income_target+total_monthly_income_target, #总目标
            "remark":u"\n".join(remark),
        }

        result.update({
            "ppv_complete_rate":result["ppv_sum_money"] / result["ppv_income_target"] if result["ppv_income_target"] else 0,
            "monthly_complete_rate":result["month_sum_money"] / result["monthly_income_target"] if result["monthly_income_target"] else 0,
            "complete_rate":result["total_sum_money"] / result["income_target"] if result["income_target"] else 0,
        })


        return result

