# -*- coding: utf-8 -*-
from base_api import forms as base_forms
from django import forms

import datetime

start_date = datetime.date.today().strftime('%Y-%m-01')
end_date = datetime.datetime.today().strftime('%Y-%m-%d')
calculate_date = datetime.datetime.today().date() -  datetime.timedelta(days=1)

def get_areanames_list(request,*args, **kwargs):
    """
    地区下拉列表
    """
    from system.models import Product
    from base_api.views import get_row_perms
    qs = Product.objects.all().values("area__zname").distinct()
    if not request.user.is_superuser:
        qs = get_row_perms(qs,request.session["area_row_perms"])
    select_list = [[v["area__zname"], v["area__zname"]] for v in qs]
    select_list.insert(0, ["",u"---ALL---"])
    return select_list

def get_areas_list(request,*args, **kwargs):
    """
    地区下拉列表
    """
    from system.models import Product
    from base_api.views import get_row_perms
    qs = Product.objects.all().values("area__zcode","area__zname").distinct()
    if not request.user.is_superuser:
        qs = get_row_perms(qs,request.session["area_row_perms"])
    select_list = [[v["area__zcode"], v["area__zname"]] for v in qs]
    select_list.insert(0, ["",u"---ALL---"])
    return select_list


def get_products_list(request, *args, **kwargs):
    u"""
        获取所有区域产品
    """
    from models import Product
    select_obj = Product.objects.values("c_name").distinct()
    select_list = [[v["c_name"],v["c_name"]]  for v in select_obj]
    select_list.insert(0, ["", u"---ALL---"])
    return select_list

MODULE_INIT_DATA = {
    "Product": {
        "form": base_forms.QueryForm(
            [
                {"label": u"区域名称", "name": "area__zcode__exact", "field_type": "ChoiceField",
                    "choices":get_areas_list,
                    "widget_attrs":{"style":"width:100px"},
                },
                {"label": u"产品名称", "name": "c_name__exact", "field_type": "ChoiceField",
                    "choices":get_products_list,
                    "widget_attrs":{"style":"width:100px"},
                },
                {"label": u"是否PPV产品", "name": "is_ppv__exact", "field_type": "ChoiceField",
                          "choices": [["",u"---ALL---"], ["1", u"是"],["0", u"否"]],},
            ]
        ),
        "operations": [
            {
                "perm": u"add__system__product",
                "js_func": "add",
                "name": u"新增",
                "icon": "icon-add",
                "params": {
                    "dialog_name": u"新增产品",
                    "url": "/api/base/system/Product/common_create/?using_db=default",
                    "width": "500",
                }
            },
            {
                "perm": u"modify__system__product",
                "js_func": "edit",
                "name": u"编辑",
                "icon": "icon-edit",
                "params": {
                    "dialog_name": u"编辑产品",
                    "url": "/api/base/system/Product/common_edit/?using_db=default",
                    "width": "500",
                }
            },
            {
                "perm": u"delete__system__product",
                "js_func": "del",
                "name": u"删除",
                "icon": "icon-remove",
                "params": {
                    "dialog_name": u"删除产品",
                    "url": "/api/base/system/Product/delete/?using_db=default",
                }
            },
        ],
        "hide_checkbox": False,
        "columns": [
            {"field": 'area__zname', "title": '区域名称', "width": 150},
            {"field": 'area__zcode', "title": '区域编码', "width": 150},
            {"field": 'c_name', "title": '产品名称', "width": 150},
            {"field": 'is_ppv', "title": '是否PPV产品', "width": 100},
            {"field": 'new_by_hand', "title": '统计方式', "width": 100},
            {"field": 'remark', "title": '备注', "width": 200},
            {"field": 'create_time', "title": '创建时间', "width": 150},
        ],
        "url": "/api/base/system/Product/query/?using_db=default&ep=T",
        "fitColumns": True
    },

    "MonthProduct": {
        "form": base_forms.QueryForm(
            [
                {"label": u"区域名称", "name": "product__area__zcode__exact", "field_type": "ChoiceField",
                    "choices":get_areas_list,
                    "widget_attrs":{"style":"width:100px"},
                },
                {"label": u"产品名称", "name": "product__c_name__exact", "field_type": "ChoiceField",
                    "choices":get_products_list,
                    "widget_attrs":{"style":"width:100px"},
                },
            ]
        ),
        "operations": [
            {
                "perm":u"repeat__system__monthdaytotalreport",
                "js_func":"multiple_select_op",
                "name":u"重新生成分析报表",
                "icon":"icon-remove",
                "params": {
                    "dialog_name":u"重新生成分析报表",
                    "postType":"remote",
                    "width":"500",
                    "height":"300",
                    "url":"/system/recalculate_monthly_report?using_db=default",
                    "confirm_url":"/system/recalculate_monthly_report?using_db=default",
                }
            },
            {
                "perm": u"add__system__monthproduct",
                "js_func": "add",
                "name": u"新增",
                "icon": "icon-add",
                "params": {
                    "dialog_name": u"新增包月产品",
                    "url": "/api/base/system/MonthProduct/common_create/?using_db=default",
                    "width": "500",
                }
            },
            {
                "perm": u"modify__system__monthproduct",
                "js_func": "edit",
                "name": u"编辑",
                "icon": "icon-edit",
                "params": {
                    "dialog_name": u"编辑包月产品",
                    "url": "/api/base/system/MonthProduct/common_edit/?using_db=default",
                    "width": "500",
                }
            },
            {
                "perm": u"delete__system__monthproduct",
                "js_func": "del",
                "name": u"删除",
                "icon": "icon-remove",
                "params": {
                    "dialog_name": u"删除包月产品",
                    "url": "/api/base/system/MonthProduct/delete/?using_db=default",
                }
            },
        ],
        "hide_checkbox": False,
        "columns": [
            {"field": 'product__area__zname', "title": '区域名称', "width": 100},
            {"field": 'product__c_name', "title": "产品名称", "width": 150},
            {"field": 'c_pay_key', "title": '支付键值', "width": 150},
            {"field": 'c_pv_key', "title": 'PV键值', "width": 150},
            {"field": 'c_table', "title": '所存储的表', "width": 100},
            {"field": 'price', "title": '单价', "width": 80},
            {"field": 'ratio', "title": '比例', "width": 80},
        ],
        "url": "/api/base/system/MonthProduct/query/?using_db=default&ep=T",
        "fitColumns": True
    },

   "PpvProduct": {
        "form": base_forms.QueryForm(
            [
                {"label": u"区域名称", "name": "product__area__zcode__exact", "field_type": "ChoiceField",
                    "choices":get_areas_list,
                    "widget_attrs":{"style":"width:100px"},
                },
            ]
        ),
        "operations": [
            {
                "perm":u"repeat__system__ppvdaytotalreport",
                "js_func":"multiple_select_op",
                "name":u"重新生成分析报表",
                "icon":"icon-remove",
                "params": {
                    "dialog_name":u"重新生成分析报表",
                    "width":"500",
                    "height":"300",
                    "title":u"日期选择",
                    "confirm_url":"/system/recalculate_ppv_report?using_db=default",
                    "postType":"remote",
                    "url":"/system/recalculate_ppv_report?using_db=default",
                }
            },
            {
                "perm": u"add__system__ppvproduct",
                "js_func": "add",
                "name": u"新增",
                "icon": "icon-add",
                "params": {
                    "dialog_name": u"新增PPV产品",
                    "url": "/api/base/system/PpvProductForm/form_create/?using_db=default",
                    "width": "500",
                }
            },
            {
                "perm": u"modify__system__ppvproduct",
                "js_func": "edit",
                "name": u"编辑",
                "icon": "icon-edit",
                "params": {
                    "dialog_name": u"编辑PPV产品",
                    "url": "/api/base/system/PpvProductForm/form_edit/?using_db=default",
                    "width": "500",
                }
            },
            {
                "perm": u"delete__system__ppvproduct",
                "js_func": "del",
                "name": u"删除",
                "icon": "icon-remove",
                "params": {
                    "dialog_name": u"删除PPV产品",
                    "url": "/api/base/system/PpvProduct/delete/?using_db=default",
                }
            },
        ],
        "hide_checkbox": False,
        "columns": [
            {"field": 'product__area__zname', "title": '区域名称', "width": 200},
            {"field": 'product__c_name', "title": '产品名称', "width": 200},
            {"field": 'c_pv_key', "title": 'PV键值', "width": 200},
            {"field": 'limit_money', "title": '限额', "width": 200},
            {"field": 'is_ott', "title": '是否OTT', "width": 200},
        ],
        "url": "/api/base/system/PpvProduct/query/?using_db=default&ep=T",
        "fitColumns": True
    },

    "MonthProductParams": {
        "form": base_forms.QueryForm(
            [
                {"label": u"月份", "name": "month__contains", "field_type": "CharField"},
                {"label": u"区域名称", "name": "product__product__area__zcode__exact", "field_type": "ChoiceField",
                    "choices":get_areas_list,
                    "widget_attrs":{"style":"width:100px"},
                },
                {"label": u"产品名称", "name": "product__product__c_name__exact", "field_type": "ChoiceField",
                    "choices":get_products_list,
                    "widget_attrs":{"style":"width:100px"},
                },
            ]
        ),
        "operations": [
            {
                "perm": u"add__system__monthproductparams",
                "js_func": "add",
                "name": u"新增",
                "icon": "icon-add",
                "params": {
                    "dialog_name": u"新增包月产品配置",
                    "url": "/api/base/system/MonthProductParamsForm/form_create/?using_db=default",
                    "width": "600",
                }
            },
            {
                "perm": u"modify__system__monthproductparams",
                "js_func": "edit",
                "name": u"编辑",
                "icon": "icon-edit",
                "params": {
                    "dialog_name": u"编辑包月产品配置",
                    "url": "/api/base/system/MonthProductParamsForm/form_edit/?using_db=default",
                    "width": "600",
                }
            },
            {
                "perm": u"delete__system__monthproductparams",
                "js_func": "del",
                "name": u"删除",
                "icon": "icon-remove",
                "params": {
                    "dialog_name": u"删除包月产品",
                    "url": "/api/base/system/MonthProductParams/delete/?using_db=default",
                }
            },
        ],
        "hide_checkbox": True,
        "columns": [
            {"field": 'month', "title": '月份', "width": 150,"sortable":True},
            {"field": 'product__product__area__zname', "title": '区域名称', "width": 150},
            {"field": 'product__product__c_name', "title": '产品名称', "width": 150},
            {"field": 'product__c_pay_key', "title": '支付键值', "width": 120},
            {"field": 'product__c_pv_key', "title": 'PV键值', "width": 120},
            {"field": 'product__price', "title": '单价', "width": 80},
            {"field": 'continue_subscribe_numbers', "title": '续订用户数', "width": 80},
            {"field": 'income_target', "title": '收入指标', "width": 80},
            {"field": 'remark', "title": '备注', "width": 150},
            {"field": 'create_time', "title": '创建时间', "width": 120,"sortable":True},
        ],
        "url": "/api/base/system/MonthProductParams/query/?using_db=default&ep=T",
        "fitColumns": True
    },

    "PpvProductParams": {
        "form": base_forms.QueryForm(
            [
                {"label": u"月份", "name": "month__contains", "field_type": "CharField"},
                {"label": u"区域名称", "name": "product__area__zcode__exact", "field_type": "ChoiceField",
                    "choices":get_areas_list,
                    "widget_attrs":{"style":"width:100px"},
                },
                {"label": u"产品名称", "name": "product__c_name__exact", "field_type": "ChoiceField",
                    "choices":get_products_list,
                    "widget_attrs":{"style":"width:100px"},
                },
            ]
        ),
        "operations": [
            {
                "perm": u"add__system__ppvproductparams",
                "js_func": "add",
                "name": u"新增",
                "icon": "icon-add",
                "params": {
                    "dialog_name": u"新增PPV产品配置",
                    "url": "/api/base/system/PpvProductParamsForm/form_create/?using_db=default",
                    "width": "600",
                }
            },
            {
                "perm": u"modify__system__ppvproductparams",
                "js_func": "edit",
                "name": u"编辑",
                "icon": "icon-edit",
                "params": {
                    "dialog_name": u"编辑PPV产品配置",
                    "url": "/api/base/system/PpvProductParamsForm/form_edit/?using_db=default",
                    "width": "600",
                }
            },
            {
                "perm": u"delete__system__ppvproductparams",
                "js_func": "del",
                "name": u"删除",
                "icon": "icon-remove",
                "params": {
                    "dialog_name": u"删除PPV产品配置",
                    "url": "/api/base/system/PpvProductParams/delete/?using_db=default",
                }
            },
        ],
        "hide_checkbox": True,
        "columns": [
            {"field": 'month', "title": '月份', "width": 150,"sortable":True},
            {"field": 'product__product__area__zname', "title": '区域名称', "width": 150},
            {"field": 'product__product__c_name', "title": '产品名称', "width": 150},
            {"field": 'income_target', "title": '收入指标', "width": 80},
            {"field": 'remark', "title": '备注', "width": 150},
            {"field": 'create_time', "title": '创建时间', "width": 120,"sortable":True},
        ],
        "url": "/api/base/system/ppvproductparams/query/?using_db=default&ep=T",
        "fitColumns": True
    },
    "PpvDayTotalReport": {
        "form": base_forms.QueryForm(
            [
                {"label":u"开始时间","name":"fdate__gte","field_type":"DateField", "initial":start_date},
                {"label":u"结束时间","name":"fdate__lte","field_type":"DateField", "initial":end_date},
                {"label": u"地区名称", "name": "area__zname__exact","field_type": "ChoiceField",
                    "choices":get_areanames_list,
                    "widget_attrs":{"style":"width:100px"},
                },
                {"label": u"数据是否异动", "name": "is_warning__exact", "field_type":"ChoiceField",
                          "choices": [["",u"---ALL---"], ["1", u"是"],["0", u"否"]]},

            ]
        ),
        "operations": [
            {
                "perm":u"export__system__ppvdaytotalreport",
                "js_func":"op_with_query_params",
                "name":u"导出",
                "icon":"icon-save",
                "params":{
                    "dialog_name":u"导出PPV产品数据分析表记录",
                    "async":False,
                    "url":"/api/base/system/PpvDayTotalReport/export?using_db=default",
                }
            },
            {
                "perm": u"add__system__ppvdaytotalreport",
                "js_func": "add",
                "name": u"新增",
                "icon": "icon-add",
                "params": {
                    "dialog_name": u"新增PPV产品数据分析表",
                    "url": "/api/base/system/PpvDayTotalReportForm/form_create/?using_db=default",
                    "width": "600",
                }
            },
            {
                "perm": u"modify__system__ppvdaytotalreport",
                "js_func": "edit",
                "name": u"编辑",
                "icon": "icon-edit",
                "params": {
                    "dialog_name": u"编辑PPV产品数据分析记录",
                    "url": "/api/base/system/PpvDayTotalReportForm/form_edit/?using_db=default",
                    "width": "600",
                }
            },
            {
                "perm": u"delete__system__ppvdaytotalreport",
                "js_func": "del",
                "name": u"删除",
                "icon": "icon-remove",
                "params": {
                    "dialog_name": u"删除PPV产品数据分析记录",
                    "url": "/api/base/system/PpvDayTotalReport/delete/?using_db=default",
                }
            },
        ],
        "hide_checkbox": False,
        "columns": [
            {"field": 'fdate', "title": u'日期', "width": 80,"sortable":True},
            {"field": 'area__zname', "title": u'区域名称', "width": 80},
            {"field": 'product_name', "title": '产品名称', "width": 80},
            {"field": 'dis_hall_access_uv', "title": u'大厅访问uv', "width": 80},
            {"field": 'hall_access_pv', "title": u'大厅访问pv', "width": 80},
            {"field": 'dis_game_start_uv', "title": u'游戏启动uv', "width": 80},
            {"field": 'game_start_pv', "title": u'游戏启动pv', "width": 80},
            {"field": 'p_success_money', "title": u'充值成功总金额', "width": 100},
            {"field": 'p_fail_money', "title": u'充值失败总金额', "width": 100},
            {"field": 'p_success_dis_count', "title": u'充值成功用户数', "width": 100},
            {"field": 'p_total_dis_count', "title": u'充值总用户数', "width": 100},
            {"field": 'p_total_count', "title": u'充值总次数', "width": 80},
            {"field": 'success_percent', "title": u'充值成功率', "width": 80},
            {"field": 'day_new_user', "title": u'大厅新增用户数', "width": 100},
            {"field": 'p_new_add_count', "title": u'新增充值用户数', "width": 100},
            {"field": 'ARPU', "title": u'人均ARPU', "width": 80},
            {"field": 'c_success_money', "title": u'消费成功金额', "width": 100},
            {"field": 'c_fail_money', "title": u'消费失败金额', "width": 100},
            {"field": 'c_total_dis_count', "title": u'消费用户数', "width": 100},
            {"field": 'c_total_count', "title": u'消费次数', "width": 80},
            {"field": 'c_new_add_count', "title": u'新增消费用户数', "width": 100},
            {"field": 'count_month_limit_user', "title": u'消费已达上限用户数', "width": 120},
            {"field": 'month_limit_money', "title": u'月消费限额', "width": 80},
            {"field": 'coins_percent', "title": u'流量转化值', "width": 80},
            {"field": 'daily_pay_percent', "title": u'日付费率', "width": 80},
            {"field": 'total_user', "title": u'历史累计总用户数', "width": 120},
            {"field": 'total_pay_user', "title": u'历史累计付费用户数', "width": 120},
            {"field": 'no_pay_user', "title": u'历史累计从来没有付费的用户数', "width": 130},
            {"field": 'is_warning', "title": u'数据异动', "width": 100,"sortable":True},
            {"field": 'remark', "title": u'信息摘要', "width": 200},
        ],
        "url": "/api/base/system/PpvDayTotalReport/query/?using_db=default&ep=T",
        "fitColumns": False,
        "js":[], #加入JS的路径
        "first_load_data":False,
        "row_style_function": "$.utils.row_style.fdate_row_style", #行显示的前端函数
    },

    "MonthDayTotalReport": {
        "form": base_forms.QueryForm(
            [
                {"label":u"开始时间","name":"fdate__gte","field_type":"DateField", "initial":start_date},
                {"label":u"结束时间","name":"fdate__lte","field_type":"DateField", "initial":end_date},
                {"label": u"地区名称", "name": "area__zname__exact", "field_type": "ChoiceField",
                    "choices":get_areanames_list,
                    "widget_attrs":{"style":"width:100px"},
                },
                {"label": u"产品名称", "name": "product_name__exact", "field_type": "ChoiceField",
                    "choices":get_products_list,
                    "widget_attrs":{"style":"width:100px"},
                },
                {"label": u"数据异动", "name": "is_warning__exact", "field_type":"ChoiceField",
                          "choices": [["",u"---ALL---"], ["1", u"是"], ["0", u"否"]]
                 }
            ]
        ),
        "operations": [
            {
                "perm":u"export__system__monthdaytotalreport",
                "js_func":"op_with_query_params",
                "name":u"导出",
                "icon":"icon-save",
                "params":{
                    "dialog_name":u"导出包月产品数据分析表记录",
                    "async":False,
                    "url":"/api/base/system/MonthDayTotalReport/export/?using_db=default",
                }
            },
            {
                "perm": u"add__system__monthdaytotalreport",
                "js_func": "add",
                "name": u"新增",
                "icon": "icon-add",
                "params": {
                    "dialog_name": u"新增包月产品数据分析",
                    "url": "/api/base/system/MonthDayTotalReportForm/form_create/?using_db=default",
                    "width": "600",
                }
            },
            {
                "perm": u"modify__system__monthdaytotalreport",
                "js_func": "edit",
                "name": u"编辑",
                "icon": "icon-edit",
                "params": {
                    "dialog_name": u"编辑包月产品数据分析记录",
                    "url": "/api/base/system/MonthDayTotalReportForm/form_edit/?using_db=default",
                    "width": "600",
                }
            },
            {
                "perm": u"delete__system__monthdaytotalreport",
                "js_func": "del",
                "name": u"删除",
                "icon": "icon-remove",
                "params": {
                    "dialog_name": u"删除包月产品数据分析记录",
                    "url": "/api/base/system/MonthDayTotalReport/delete/?using_db=default",
                }
            },
        ],
        "hide_checkbox": False,
        "columns": [
            {"field": 'fdate', "title": '日期', "width": 80,"sortable":True},
            {"field": 'area__zname', "title": '地区名称', "width": 80,"sortable":True},
            {"field": 'product_name', "title": '产品名称', "width": 80},
            {"field": 'dis_hall_access_uv', "title": '大厅访问用户数', "width": 100},
            {"field": 'hall_access_pv', "title": '大厅访问次数', "width": 100},
            {"field": 'p_success_dis_count', "title": '成功订购用户数', "width": 100},
            {"field": 'c_percent', "title": '转换率', "width": 80},
            {"field": 'dis_order_page_user_uv', "title": '订购页面访问uv', "width": 100},
            {"field": 'day_new_user', "title": '大厅新增用户数', "width": 100},
            {"field": 'dis_total_first_login_and_order_user', "title": '第一次进来并订购的用户数', "width": 130},
            {"field": 'dis_hall_already_order_count', "title": '已经订购的访问用户', "width": 120},
            {"field": 'success_percent', "title": '订购成功率', "width": 80},
            {"field": 'p_fail_dis_count', "title": '失败订购用户数', "width": 100},
            {"field": 'dis_game_start_uv', "title": '游戏启动uv', "width": 80},
            {"field": 'game_start_pv', "title": '游戏启动pv', "width": 80},
            {"field": 'p_success_money', "title": '成功总金额', "width": 80},
            {"field": 'p_subscribe_success_money', "title": '当天续订总金额', "width": 80},
            {"field": 'p_fail_money', "title": '失败总金额', "width": 80},
            {"field": 'p_new_add_count', "title": '新增订购用户数', "width": 100},
            {"field": 'order_page_user_pv', "title": '订购页面访问pv', "width": 100},
            {"field": 'total_user', "title": '历史累计总用户数', "width": 130},
            {"field": 'total_pay_user', "title": '历史累计订购用户数', "width": 130},
            {"field": 'no_pay_user', "title": '历史累未订购用户数', "width": 130},
            {"field": 'is_warning', "title": '数据异动', "width": 80,"sortable":True},
            {"field": 'remark', "title": '信息摘要', "width": 200},
        ],
        "url": "/api/base/system/MonthDayTotalReport/query/?using_db=default&ep=T",
        "fitColumns": False,
        "first_load_data":False,
        "row_style_function": "$.utils.row_style.fdate_row_style", #行显示的前端函数
    },
    "IncomeTotalReport": {
        "form": base_forms.QueryForm(
            [
                {"label":u"统计开始日期","name":"month__gte","field_type":"DateField", "initial":start_date},
                {"label":u"统计结束日期","name":"month__lte","field_type":"DateField", "initial":calculate_date},
                {"label": u"地区名称", "name": "area__zname__exact", "field_type": "ChoiceField",
                 "choices":get_areanames_list,
                 "widget_attrs":{"style":"width:100px"},
                 },
                ]
        ),
        "operations": [
            {
                "perm":u"export__system__incometotalreport",
                "js_func":"op_with_query_params",
                "name":u"导出",
                "icon":"icon-save",
                "params":{
                    "dialog_name":u"导出产品收入完成度",
                    "async":False,
                    "url":"/api/base/system/IncomeTotalReport/export/?using_db=default",
                    }
            },
            {
                "perm": u"add__system__incometotalreport",
                "js_func": "add",
                "name": u"新增",
                "icon": "icon-add",
                "params": {
                    "dialog_name": u"新增产品收入完成度",
                    "url": "/api/base/system/IncomeTotalReportForm/form_create/?using_db=default",
                    "width": "620",
                    "height":"600",
                }
            },
            {
                "perm": u"modify__system__incometotalreport",
                "js_func": "edit",
                "name": u"编辑",
                "icon": "icon-edit",
                "params": {
                    "dialog_name": u"编辑产品收入完成度",
                    "url": "/api/base/system/IncomeTotalReportForm/form_edit/?using_db=default",
                    "width": "620",
                    "height":"620",
                }
            },
            {
                "perm": u"delete__system__incometotalreport",
                "js_func": "del",
                "name": u"删除",
                "icon": "icon-remove",
                "params": {
                    "dialog_name": u"删除产品收入完成度",
                    "url": "/api/base/system/IncomeTotalReport/delete/?using_db=default",
                    }
            },
            ],
        "hide_checkbox": False,
        "columns": [
            {"field": 'month', "title": '统计日期', "width": 80,"sortable":True},
            {"field": 'area__zname', "title": '地区名称', "width": 120,"sortable":True},
            {"field": 'ppv_sum_money', "title": 'PPV流水(成功)', "width": 120,"sortable":True},
            {"field": 'ppv_income_target', "title": 'PPV收入指标', "width": 100,"sortable":True},
            {"field": 'ppv_complete_rate', "title": 'PPV完成度', "width": 100,"sortable":True},
            {"field": 'month_sum_money', "title": '包月流水(成功)', "width": 120,"sortable":True},
            {"field": 'monthly_income_target', "title": '包月收入指标', "width": 100,"sortable":True},
            {"field": 'monthly_complete_rate', "title": '包月完成度', "width": 100,"sortable":True},
            {"field": 'total_sum_money', "title": '总流水', "width": 120,"sortable":True},
            {"field": 'income_target', "title": '总收入指标', "width": 100,"sortable":True},
            {"field": 'complete_rate', "title": '总完成度', "width": 100,"sortable":True},
            {"field": 'create_time', "title": '创建时间', "width": 120,"sortable":True},
            {"field": 'remark', "title": '信息摘要', "width": 250},
            ],
        "url": "/api/base/system/IncomeTotalReport/query/?using_db=default",
        "fitColumns": True,
        "row_style_function": "$.utils.row_style.month_day_style",
        "first_load_data":False,
    },

    "ReceiverConfig": {
        "form": base_forms.QueryForm(
            [
                {"label":u"用户名称","name":"user__username__contains","field_type":"CharField"},
            ]
        ),
        "operations": [
            {
                "perm": u"add__system__receiverconfig",
                "js_func": "add",
                "name": u"新增",
                "icon": "icon-add",
                "params": {
                    "dialog_name": u"新增报表接收者配置",
                    "url": "/api/base/system/ReceiverConfigForm/form_create/?using_db=default",
                    "width": "600",
                }
            },
            {
                "perm": u"modify__system__receiverconfig",
                "js_func": "edit",
                "name": u"编辑",
                "icon": "icon-edit",
                "params": {
                    "dialog_name": u"编辑报表接收者配置",
                    "url": "/api/base/system/ReceiverConfigForm/form_edit/?using_db=default",
                    "width": "600",
                }
            },
            {
                "perm": u"delete__system__receiverconfig",
                "js_func": "del",
                "name": u"删除",
                "icon": "icon-remove",
                "params": {
                    "dialog_name": u"删除报表接收者配置",
                    "url": "/api/base/system/ReceiverConfig/delete/?using_db=default",
                }
            },
        ],
        "hide_checkbox": False,
        "columns": [
            {"field": 'report_type__c_name', "title": '报表类型', "width": 150},
            {"field": 'send_type', "title": '发送类别', "width": 150},
            {"field": 'create_time', "title": '创建时间', "width": 120,"sortable":True},
        ],
        "url": "/api/base/system/ReceiverConfig/query/?using_db=default&ep=T",
        "fitColumns": True
    },
}
