# -*- coding: utf-8 -*-
from django.db import models
from django.contrib.contenttypes.models import ContentType
from django.contrib.admin.util import quote
from django.utils.encoding import smart_unicode
from django.utils.safestring import mark_safe
from django.utils.translation import ugettext_lazy as _
from django.contrib.auth.models import Permission,AbstractUser,Group
from django.conf import settings
from django.core import validators
import json
from django.core.cache import cache
from module_define import MODULE_INIT_DATA as system_init_data
from report_define import MODULE_INIT_DATA as report_init_data

MODULE_INIT_DATA = {}
MODULE_INIT_DATA.update(system_init_data)
MODULE_INIT_DATA.update(report_init_data)

ALL_MODULES = [
    {
        "module_code":u"SystemIndex",
        "module_name":u"系统首页",
        "url":"/ui_main",
        "codename":u"browse__system__systemindex",
        "name":u"浏览系统首页",
        "perms":[
            {"codename":u"change_pwd__system__systemindex","name":u"修改密码",},
            {"codename":u"set_area_to_session__system__systemremote","name":u"首页设置区域",},
             {"codename":u"test_port_is_ok__system__systemremote","name":u"测试网络联通情况",},
        ]
    },
    {
        "module_code":u"User",
        "module_name":u"用户管理",
        "url":"/api/base/system/User/load/",
        "codename":u"browse__system__user",
        "name":u"浏览用户",
        "perms":[
            {"codename":u"add__system__user","name":u"新增用户",},
            {"codename":u"modify__system__user","name":u"修改用户",},
            {"codename":u"delete__system__user","name":u"删除用户",},
        ]
    },
    {
        "module_code":u"Group",
        "module_name":u"角色管理",
        "url":"/api/base/system/Group/load/",
        "codename":u"browse__system__group",
        "name":u"浏览角色",
        "perms":[
            {"codename":u"add__system__group","name":u"新增角色",},
            {"codename":u"modify__system__group","name":u"修改角色",},
            {"codename":u"delete__system__group","name":u"删除角色",},
        ]
    },
    {
        "module_code":u"Area",
        "module_name":u"区域管理",
        "url":"/api/base/system/Area/load/",
        "codename":u"browse__system__area",
        "name":u"浏览区域",
        "perms":[
            {"codename": u"repeat__system__incometotalreport","name":u"重新生成完成度报表",},
            {"codename":u"add__system__area","name":u"新增区域",},
            {"codename":u"modify__system__area","name":u"修改区域",},
            {"codename":u"delete__system__area","name":u"删除区域",},
        ]
    },
    {
        "module_code":u"LogEntry",
        "module_name":u"系统操作日志记录",
        "url":"/api/base/system/LogEntry/load/",
        "codename":u"browse__system__logentry",
        "name":u"浏览系统操作日志",
        "perms":[
            {"codename":u"view_detail__system__logentry","name":u"查看日志详情",},
        ]
        
    },{
       "module_code":u"reports_settings",
       "module_name":u"参数设置",
       "url":"/system/load_settings_page",
       "codename":u"browse__system__reports_settings",
       "name":u"报表设置",
       "perms":[
            {"codename":u"browse__system__areaparams","name":u"浏览地区参数配置",},
            {"codename":u"add__system__areaparams","name":u"新增地区参数配置",},
            {"codename":u"modify__system__areaparams","name":u"修改地区参数配置",},
            {"codename":u"delete__system__areaparams","name":u"删除地区参数配置",},
       ]
   },
    {
       "module_code":u"SyncLog",
       "module_name":u"订单同步日志",
       "url":"/api/base/system/SyncLog/load/",
       "codename":u"browse__system__synclog",
       "name":u"订单同步日志",
       "perms":[
            {"codename":u"modify__system__synclog","name":u"订单同步日志",},
       ]
   },
    {
       "module_code":u"RetryTask",
       "module_name":u"订单重传日志",
       "url":"/api/base/system/RetryTask/load/",
       "codename":u"browse__system__retrytask",
       "name":u"订单重传日志",
       "perms":[
            {"codename":u"modify__system__synclog","name":u"订单重传日志",},
       ]
   }, 
    {
         "module_code":u"TestUser",
         "module_name":u"测试账号",
         "url":"/api/base/system/TestUser/load/",
         "codename":u"browse__system__testuser",
         "name":u"测试账号",
         "menu_key":"reports",
         "perms":[
              {"codename":u"add__system__testuser","name":u"新增",},
              {"codename":u"modify__system__testuser","name":u"修改",},
              {"codename":u"delete__system__testuser","name":u"删除",},
         ]
     }, 
   {
       "module_code":u"DatabaseManage",
       "module_name":u"数据库连接配置",
       "url":"/api/base/system/DatabaseManage/load/",
       "codename":u"browse__system__databasemanage",
       "name":u"数据库连接配置",
       "perms":[
            {"codename":u"add__system__databasemanage","name":u"新增",},
            {"codename":u"modify__system__databasemanage","name":u"修改",},
            {"codename":u"delete__system__databasemanage","name":u"删除",},
       ]
   },
   {
       "module_code":u"DataSyncConfig",
       "module_name":u"导数据配置",
       "url":"/api/base/system/DataSyncConfig/load/",
       "codename":u"browse__system__datasyncconfig",
       "name":u"数据库连接配置",
       "perms":[
            {"codename":u"add__system__datasyncconfig","name":u"新增",},
            {"codename":u"modify__system__datasyncconfig","name":u"修改",},
            {"codename":u"delete__system__datasyncconfig","name":u"删除",},
       ]
   },
   {
       "module_code":u"Product",
       "module_name":u"区域-产品管理",
       "url":"/api/base/system/Product/load/",
       "codename":u"browse__system__product",
       "name":u"区域-产品管理",
       "menu_key":"reports",
       "perms":[
            {"codename":u"add__system__product","name":u"新增产品",},
            {"codename":u"modify__system__product","name":u"修改产品",},
            {"codename":u"delete__system__product","name":u"删除产品",},
       ]
   },
   {
       "module_code":u"PpvProduct",
       "module_name":u"PPV产品单价管理",
       "url":"/api/base/system/PpvProduct/load/",
       "codename":u"browse__system__ppvproduct",
       "name":u"PPV产品单价管理",
       "menu_key":"reports",
       "perms":[
            {"codename":u"add__system__ppvproduct","name":u"新增PPV产品",},
            {"codename":u"modify__system__ppvproduct","name":u"修改PPV产品",},
            {"codename":u"delete__system__ppvproduct","name":u"删除PPV产品",},
            {"codename": u"repeat__system__ppvdaytotalreport","name":u"重新生成报表",},
       ]
   },
   {
       "module_code":u"MonthProduct",
       "module_name":u"包月产品单价管理",
       "url":"/api/base/system/MonthProduct/load/",
       "codename":u"browse__system__monthproduct",
       "name":u"包月产品单价管理",
       "menu_key":"reports",
       "perms":[
           {"codename":u"add__system__monthproduct","name":u"新增产品",},
           {"codename":u"modify__system__monthproduct","name":u"修改产品",},
           {"codename":u"delete__system__monthproduct","name":u"删除产品",},
           {"codename": u"repeat__system__monthdaytotalreport","name":u"重新生成报表",},
           ]
   },
   {
       "module_code":u"PpvProductParams",
       "module_name":u"PPV产品每月指标管理",
       "url":"/api/base/system/PpvProductParams/load/",
       "codename":u"browse__system__ppvproductparams",
       "name":u"PPV产品每月指标管理",
       "menu_key":"reports",
       "perms":[
            {"codename":u"add__system__ppvproductparams","name":u"新增PPV产品指标",},
            {"codename":u"modify__system__ppvproductparams","name":u"修改PPV产品指标",},
            {"codename":u"delete__system__ppvproductparams","name":u"删除PPV产品指标",},
       ]
   },
   {
       "module_code":u"MonthProductParams",
       "module_name":u"包月产品每月指标管理",
       "url":"/api/base/system/MonthProductParams/load/",
       "codename":u"browse__system__monthproductparams",
       "name":u"包月产品每月指标管理",
       "menu_key":"reports",
       "perms":[
           {"codename":u"add__system__monthproductparams","name":u"新增包月产品指标",},
           {"codename":u"modify__system__monthproductparams","name":u"修改包月产品指标",},
           {"codename":u"delete__system__monthproductparams","name":u"删除包月产品指标",},
           ]
   },
   {
       "module_code":u"PpvDayTotalReport",
       "module_name":u"PPV产品数据分析报表",
       "url":"/api/base/system/PpvDayTotalReport/load/",
       "codename":u"browse__system__ppvdaytotalreport",
       "name":u"PPV产品数据分析报表",
       "menu_key":"reports",
       "perms":[
            {"codename": u"add__system__ppvdaytotalreport","name":u"新增PPV产品数据分析报表",},
            {"codename":u"export__system__ppvdaytotalreport","name":u"导出PPV产品数据分析报表",},
            {"codename":u"modify__system__ppvdaytotalreport","name":u"修改PPV产品数据分析报表",},
            {"codename":u"delete__system__ppvdaytotalreport","name":u"删除PPV产品数据分析报表",},
       ]
   },
   {
       "module_code":u"MonthDayTotalReport",
       "module_name":u"包月产品数据分析报表",
       "url":"/api/base/system/MonthDayTotalReport/load/",
       "codename":u"browse__system__monthdaytotalreport",
       "name":u"包月产品数据分析报表",
       "menu_key":"reports",
       "perms":[
            {"codename":u"export__system__monthdaytotalreport","name":u"导出包月产品数据分析报表",},
            {"codename":u"add__system__monthdaytotalreport","name":u"新增包月产品数据分析报表",},
            {"codename":u"modify__system__monthdaytotalreport","name":u"修改包月产品数据分析报表",},
            {"codename":u"delete__system__monthdaytotalreport","name":u"删除包月产品数据分析报表",},
       ]
   },
   {
       "module_code":u"IncomeTotalReport",
       "module_name":u"产品收入完成度月报表",
       "url":"/api/base/system/IncomeTotalReport/load/",
       "codename":u"browse__system__incometotalreport",
       "name":u"产品收入完成度管理",
       "menu_key":"reports",
       "perms":[
           {"codename": u"add__system__incometotalreport","name":u"新增产品收入完成度",},
           {"codename": u"modify__system__incometotalreport","name":u"修改产品收入完成度",},
           {"codename": u"export__system__incometotalreport","name":u"导出产品收入完成度",},
           {"codename": u"delete__system__incometotalreport","name":u"删除产品收入完成度",},
           ]
   },
   {
       "module_code":u"ReceiverConfig",
       "module_name":u"报表-接收者管理",
       "url":"/api/base/system/ReceiverConfig/load/",
       "codename":u"browse__system__receiverconfig",
       "name":u"报表-接收者管理",
       "perms":[
            {"codename":u"add__system__receiverconfig","name":u"增加报表-接收者配置",},
            {"codename":u"modify__system__receiverconfig","name":u"修改报表-接收者配置",},
            {"codename":u"delete__system__receiverconfig","name":u"删除报表-接收者配置",},
       ]
   },
  {
       "module_code":u"SqlRecord",
       "module_name":u"SQL记录表",
       "url":"/api/base/system/SqlRecord/load/",
       "codename":u"browse__system__sqlrecord",
       "name":u"SQL记录表",
       "perms":[
            {"codename":u"add__system__sqlrecord","name":u"增加",},
            {"codename":u"modify__system__sqlrecord","name":u"修改",},
            {"codename":u"delete__system__sqlrecord","name":u"删除",},
       ]
   },
]

verbose_name = u"系统管理"

index = 10
#区域定义

HALL_TYPE = (
    ("hd",u"高清"),
    ("sd",u"标清")
)

YES_OR_NO = (
    ("T",u"有效"),
    ("F",u"无效"),
)


YES_OR_NO2 = (
    ("T",u"是"),
    ("F",u"否"),
)
 
class AdminContentType(object):
    list_fields = [
        "id","app_label","model","name"
    ]

ContentType.Admin = AdminContentType
class AppModel(models.Model):
    u"""应用的权限全部以这个模型为准"""
    class Meta:
        app_label = "system"
        verbose_name = u"所有权限依附的表"


class OpType(models.Model):
    type_code = models.CharField(_(u"类别代码"), max_length=50,editable = False,null=True,blank=True)
    verbose_name = models.CharField(_(u"操作类"), max_length=100,null=True,blank=True)
    remark = models.CharField(_(u"操作类别"), max_length=300,null=True,blank=True)
    enable = models.CharField( u"是否有效", max_length = 2,choices=YES_OR_NO, null = False, blank=False,default="T",help_text = u"是否有效" )

    def __unicode__(self):
        return u"%s-%s"%(self.type_code,self.verbose_name)
    class Meta:
        app_label = "system"
        verbose_name = _(u"操作类别")
        verbose_name_plural = _(u"操作类别")
        
    class Admin:
        list_fields = ["type_code","verbose_name","remark"]
        @classmethod
        def initial_data(cls):
            u"""
                初始化INITIAL_DICT的记录
            """
            import op_define
            keys = [elem["type_code"] for elem in op_define.INITIAL_DICT ]
            objs = OpType.objects.filter(type_code__in = keys)
            for elem in op_define.INITIAL_DICT:
                flag = True
                for obj in objs:
                    if obj.type_code == elem["type_code"]:
                        flag = False
                        break
                if flag:
                    OpType(**{
                        "type_code":elem["type_code"],
                        "verbose_name":u"%s"%elem["verbose_name"]
                    }).save()


class Area(models.Model):
    u"区域代码"
    zcode = models.CharField(u"区域代码", max_length=50,null=True,blank=True,unique=True)
    zname = models.CharField(u"区域名称", max_length=100,null=True,blank=True)
    root_path_name = models.CharField(u"区域根目录名称", max_length=100,null=True,blank=True,unique=True)
    hall_type = models.CharField(u"区域名称", max_length=100,choices=HALL_TYPE,null=True,blank=True)
    parent = models.ForeignKey("self",verbose_name = u"父级",related_name="area_parent",null=True,blank=True,on_delete=models.SET_NULL,)
    c_sort = models.IntegerField(u"排序", null=False, default=1000)
    
    def __unicode__(self):
        return self.zname
    
    class Meta:
        app_label = "system"
        verbose_name = u"系统用户"
    
    @classmethod
    def get_system_area(cls):
        u"""
        获取系统区域
        """
        area = cache.get(settings.CACHE_PREX_SYSTEM_AREA)
        if not area:
            area = Area.objects.get(zcode="00000")
            cache.set(settings.CACHE_PREX_SYSTEM_AREA,area,settings.TIMEOUT_SYSTEM_AREA)
        
        return area
    
    class Admin:
        list_fields = ["id","parent__zname","zcode","zname","root_path_name","c_sort","hall_type"]
        is_open_row_perms = True
        #树形控件的配置
        tree_parent_node_name = "parent"
        tree_node_name = "zname"
        
        @classmethod
        def initial_data(cls):
            from area_define import AREA_CODE_DEFINE
            keys = [elem["zcode"] for elem in AREA_CODE_DEFINE ]
            objs = Area.objects.filter(zcode__in = keys)
            for elem in AREA_CODE_DEFINE:
                flag = True
                for obj in objs:
                    if obj.zcode == elem["zcode"]:
                        flag = False
                        break
                if flag:
                    Area(**{
                        "zcode":elem["zcode"],
                        "zname":u"%s"%elem["zname"],
                        "root_path_name":u"%s"%elem["root_path_name"],
                        "hall_type":elem["hall_type"],
                    }).save()
                    

class LogEntry(models.Model):
    area = models.ForeignKey(Area,verbose_name=u"地区",related_name="area_code",null=True,blank=True,on_delete=models.SET_NULL,)
    action_time = models.DateTimeField(u"操作开始时间", auto_now=True)
    end_time = models.DateTimeField(u"操作结束时间", auto_now=True)
    user = models.ForeignKey(settings.AUTH_USER_MODEL, related_name="op_user",verbose_name=u"操作用户",null=True,blank=True,on_delete=models.SET_NULL,)#操作的用户
    content_type = models.ForeignKey(ContentType, blank=True, null=True, related_name="content_type",verbose_name=u"操作的表",on_delete=models.SET_NULL,)#操作的表
    object_id = models.CharField(u"唯一标示", max_length=4000,blank=True, null=True)
    object_repr = models.CharField(u"操作详情",max_length=4000, )
    op_type =models.ForeignKey(OpType, related_name="op_type",verbose_name=u"操作类别",null=True,blank=True,on_delete=models.SET_NULL,)#如新增，修改，删除，等等
    change_message = models.CharField(u"修改信息", max_length=4000, blank=True, null=True)
    enable = models.CharField( u"是否有效", max_length = 2,choices=YES_OR_NO, null = False, blank=False,default="T",help_text = u"是否有效" )
#    
#    def func_view_area(self,value):
#        print 'value=====',value
#        return u"%s"%value 
    
    class Meta:
        app_label = "system"
        verbose_name = u"日志"
        verbose_name_plural = u"日志"
        ordering = ("-action_time",)
    class Admin:
        list_fields = ["area__zcode","area__zname","action_time","end_time","content_type__model","content_type__name","object_id","object_repr","op_type","change_message","user__username","content_type__app_label","content_type__id","op_type__verbose_name","id"]   
    @classmethod
    def log_action(cls, 
                    user_id,op_type, content_type_id=None, 
                    object_id =None, object_repr="", 
                    change_message="",
                    area_id = None
                ):
        obj = LogEntry()
        obj.user_id = user_id
        obj.content_type_id = content_type_id
        obj.object_id = object_id
        obj.object_repr = object_repr
        obj.op_type = op_type
        obj.change_message = change_message
        obj.area_id = area_id
        obj.save()
        return obj
        
    def __repr__(self):
        return smart_unicode(self.action_time)
    
    @classmethod
    def log(cls,
            user_id,action_type_str = None,old_instance = None,
            new_instance = None,object_id ="", object_repr ="",
            content_type_id=None,area_id = None,change_message = None
        ):
        
        if not change_message:
            change_message = []
            
        if new_instance:
            content_type_id = ContentType.objects.get_for_model(new_instance.__class__).pk
        op_type = None
        
        #操作总信息
        if (not object_repr) and new_instance:
            object_repr = u"%s"%new_instance
            
        #修改的信息
        if new_instance:
            for field in new_instance._meta.fields:
                field_name = field.name
                old_value = ""
                
                if field.choices:
                    if old_instance:
                        old_value = (old_instance.__getattribute__("get_"+field_name+"_display")()) or ""
                    new_value = (new_instance.__getattribute__("get_"+field_name+"_display")()) or ""
                else:
                    if old_instance:
                        old_value = getattr(old_instance, field_name)
                    new_value = getattr(new_instance, field_name)
                flag = True
                if str(type(old_value))=="<type 'datetime.time'>" or str(type(new_value))=="<type 'datetime.time'>":
                    flag=False    
                if new_value != old_value and not ((old_value or "None") == (new_value or "None") and flag):
                    change_message.append(u"%s(%s->%s)" % (field.verbose_name, old_value or "", new_value or ""))
        change_message = u",".join(change_message)
        
        #操作的类别，如果是模型的话，查找操作模型的说明ContentType
        try:
            op_type = OpType.objects.get(type_code = action_type_str)
        except:
            import traceback
            traceback.print_exc()
        
        cls.log_action(**{
            "user_id":user_id,
            "op_type":op_type,
            "content_type_id":content_type_id,
            "object_id":object_id,
            "object_repr":object_repr,
            "change_message":change_message,
            "area_id":area_id,
        })
    
    @classmethod
    def log_new(cls,user_id,new_instance,area_id=None):
        u"新增日志"
        return cls.log(
            user_id,
            action_type_str= "add",
            new_instance = new_instance,
            area_id = area_id
        )
    
    @classmethod
    def log_edit(cls,user_id,old_instance,new_instance,area_id=None):
        u"编辑的日志"
        return cls.log(
            user_id,
            action_type_str= "change",
            old_instance=old_instance,
            new_instance = new_instance,
            area_id=area_id
        )
    
    @classmethod
    def log_delete(cls,user_id,object_id,object_repr,model_cls,area_id=None):
        u"删除的日志"
        content_type_id = ContentType.objects.get_for_model(model_cls).pk
        
        return cls.log(
            user_id,
            action_type_str = "delete",
            object_id = object_id,
            object_repr = object_repr,
            content_type_id=content_type_id,
            area_id=area_id
        )

    @classmethod
    def log_self(cls,user_id,action_type_str,object_id,object_repr,model_cls=None,area_id=None):
        u"自定义日志"
        content_type_id = None
        if model_cls:
            content_type_id = ContentType.objects.get_for_model(model_cls).pk
            
        return cls.log(
            user_id,
            object_id=object_id,
            object_repr=object_repr,
            action_type_str = action_type_str,
            area_id=area_id,
            content_type_id = content_type_id,
        )


class AreaPermission(models.Model):
    u"区域权限"
    area = models.ForeignKey(Area, related_name="area",verbose_name=u"区域")
    permission = models.ForeignKey(Permission, related_name="permission",verbose_name=u"权限")
    
    @classmethod
    def check_area_perm(cls,area_code,perm_name):
        u"""
        @area_code 区域编码
        @perm_name 权限代码
        """
        is_exist = AreaPermission.filter(
                    area__zcode=area_code,
                    permission__codename=perm_name
                ).exists()
        
        return is_exist
    
    @classmethod
    def get_area_perms(cls,area_code):
        u"""
            获取区域所有的权限，如果缓存中存在则这几返回
        """
        cache_key = "%(prex)s_%(area_code)s"%{"prex":settings.CACHE_PREX_AREA_PERMISSION,"area_code":area_code}
        
        result = cache.get(cache_key)
        if result is None:
            relate_objs = list(AreaPermission.objects.filter(area__zcode=area_code))
            result = []
            for elem in relate_objs:
                result.append(elem.permission)
            cache.set(cache_key,result,settings.TIMEOUT_AREA_PERMISSION)
            
        return result
    
    class Admin:
        list_fields = [
            "id","area__zname","permission"
        ]
    
    class Meta:
        app_label = "system"
        verbose_name = u"区域权限"
        

class ColumnForPermission(models.Model):
    u"""某个权限所含有的列，即列权限"""
    perm = models.ForeignKey(Permission,verbose_name=u"所属权限")
    table_index = models.IntegerField(verbose_name = u"表索引", db_index=True)
    table_name  = models.CharField(verbose_name = u"表名", max_length=100)
    column_name = models.CharField(verbose_name = u"列名称", max_length=100)
    column_code = models.CharField(verbose_name = u"列代码", max_length=100)
    
    class Meta:
        verbose_name = u"列权限"
    
    
class User(AbstractUser):
    u"""
        用户表
        @column_perms:
            {
                permid1:[{table_index1:"",table_name1:"",columns:{col1:col_key1,col2:col_key2...}},...],
                permid2:[{table_index2:"",table_name2:"",columns:{col1:col_key1,col2:col_key2...}},...],
            }
    """
    level = models.IntegerField(u"用户等级", db_index= True, blank=False,null=False,default=0)
    create_user = models.ForeignKey(settings.AUTH_USER_MODEL, verbose_name=u"创建者",related_name="cc",on_delete=models.SET_NULL, null=True,blank=True)
    column_perms = models.CharField(u"列权限", max_length=4000, blank=True,null=True)

    def __unicode__(self):
        return self.username
    
    @classmethod
    def render_column_is_active(cls,value):
        ret = u"<font color='green'>有效</font>"
        if not value:
            ret = u"<font color='red'>无效</font>"
        return ret

    @classmethod
    def render_column_is_superuser(cls,value):
        ret = u"是"
        if not value:
            ret = u"否"
        return ret
    
    @classmethod
    def _get_perms(cls,user,areacode):
        u"""
        只有用户有行权限，每个用户一个地区一条记录，存储该区域的行权限
        （超级管理员就不要走这个函数了）
            {{areacode}}:{
                "{{app_label__model_name}}":{
                    "filters":{},
                    "filters_ors":[[],...],
                    "excludes":{},
                    "excludes_ors":[[],...]
                }...
            }
        """
        #用户权限
        u_filters = {
            "user__id": user.pk,
            "areacode":  areacode,
        }
        
        u_row_perms = list(
            UserRowPermission.objects.filter(
                **u_filters
            )
        )
        
        result = {}
        
        for obj in u_row_perms:
            if obj.areacode in result: #如果用户中也存在该模块的配置择覆盖，因为有些条件不知道怎么合并是AND 还是 OR
                if obj.all_filters:
                    result[obj.areacode] = json.loads(obj.all_filters)
            else:
                if obj.all_filters:
                    result.setdefault(obj.areacode,{}).update(
                        json.loads(obj.all_filters)
                    )
                
        return result
    
    @classmethod
    def get_all_model_row_filter_with_user(cls,user, areacode=None):
        u"""
            得到用户某个区域所有的模型，行级别权限
        """
        perm_filters = cls._get_perms(user,areacode) 
        
        return perm_filters
    
    class Meta(AbstractUser.Meta):
        swappable = 'AUTH_USER_MODEL'
        db_table = "user"
        verbose_name = u"系统用户"
    
    class Admin:
        list_fields = [
               'id', 'username', 'first_name', 'last_name', 'email','password',
               'is_staff', 'is_active', 'is_superuser', 'level', 'create_user__username', 'last_login', 'date_joined'
           ]
           
class AdminGroup(object):
    list_fields = [
        "id", "name"
    ]

Group.Admin = AdminGroup


def get_form(form_name):
    u"""
        得到当前应用的表单
    """
    import forms
    all_forms =  {
        "UserForm":forms.UserForm,
        "GroupForm":forms.GroupForm,
        "AreaForm":forms.AreaForm,
        "SyncLogForm":forms.SyncLogForm,
        "RetryTaskForm":forms.RetryTaskForm,
        "DatabaseManageForm":forms.DatabaseManageForm,
        "DataSyncConfigForm":forms.DataSyncConfigForm,
        "PpvProductForm":forms.PpvProductForm,
        "MonthDayTotalReportForm": forms.MonthDayTotalReportForm,
        "IncomeTotalReportForm":forms.IncomeTotalReportForm,
        "PpvDayTotalReportForm": forms.PpvDayTotalReportForm,
        "MonthProductParamsForm": forms.MonthProductParamsForm,
        "PpvProductParamsForm":forms.PpvProductParamsForm,
        "ReceiverConfigForm":forms.ReceiverConfigForm,
        "TestUserForm":forms.TestUserForm,
    }
    
    if form_name in all_forms:
        return all_forms[form_name]
    
    return None

class Type(models.Model):
    u"类别表"
    c_key = models.CharField(u"类型key",max_length=20,blank=True,null=True)
    c_name = models.CharField(u"类型名称",max_length=40,blank=True,null=True)
    c_memo = models.CharField(u"类型说明",max_length=50,blank=True,null=True)
    class Admin:
        list_fields = [
            "c_key","c_name","id","c_memo"
        ]
        init_index = 1
        @classmethod
        def initial_data(cls):
            u"""
                初始化INITIAL_DICT的记录
            """
            params = [
                {"c_name":u"充值相关","c_key":"pay","c_memo":u"充值相关参数设置，如每月充值限额"},
                {"c_name":u"包月统计报表","c_key":"month_report","c_memo":u"包月报表统计"},
                {"c_name":u"阀值","c_key":"threshold","c_memo":u"阀值"},
            ]
            for elem in params:
                is_exist =  Type.objects.filter(c_key=elem["c_key"]).exists()
                if not is_exist:
                    Type(**{
                        "c_key":elem["c_key"],
                        "c_name":u"%s"%elem["c_name"],
                        "c_memo":u"%s"%elem["c_memo"]
                    }).save()

class Params(models.Model):
    c_key = models.CharField(u"参数键值",max_length=20,blank=True,null=True)
    c_name = models.CharField(u"参数名称",max_length=40,blank=True,null=True)
    c_type = models.ForeignKey(Type, verbose_name=u"类别")
    value = models.CharField(u"参数值",max_length=600,blank=True,null=True,help_text=u"参数值")
    
    class Admin:
        list_fields = [
            "c_key","c_name","id"
        ]
        init_index = 2

        @classmethod
        def initial_data(cls):
            u"""
                初始化INITIAL_DICT的记录
            """
            params = [
                {"c_name":u"月充值限额","c_key":"month_pay_limit","c_type__c_key":"pay"},
                {"c_name":u"游戏标清包月大厅","c_key":"month_hall","c_type__c_key":"month_report",
                    "value":u'''
                        {"app_label":"game","pay_keys":["gamemonthhall"],"pv_keys":["month_hall"]}
                    '''
                },
                {"c_name":u"游戏标清包月大厅2","c_key":"month_hall_two","c_type__c_key":"month_report",
                 "value":u'''
                     {"app_label":"game","pay_keys":["gamemonthhalltwo"],"pv_keys":["month_hall_two"]}
                 '''
                },
                
                {"c_name":u"维语包月大厅","c_key":"month_hall_weiyu","c_type__c_key":"month_report",
                 "value":u'''
                     {"app_label":"game","pay_keys":["gamemonthhall"],"pv_keys":["month_hall_weiyu"]}
                 '''
                },
                {"c_name":u"哈语包月大厅","c_key":"month_hall_hayu","c_type__c_key":"month_report",
                 "value":u'''
                     {"app_label":"game","pay_keys":["hayumonthhall"],"pv_keys":["month_hall_hayu"]}
                 '''
                },
                {"c_name":u"游戏高清包月大厅","c_key":"month_hall_hd","c_type__c_key":"month_report",
                 "value":u'''
                     {"app_label":"game","pay_keys":["gamemonthhallhd"],"pv_keys":["month_hall_hd"]}
                 '''
                },
                {"c_name":u"教育标清包月大厅","c_key":"educenter","c_type__c_key":"month_report",
                "value":u'''
                     {"app_label":"game","pay_keys":["educenter"],"pv_keys":["eduhipi"]}
                 '''
                },
                {"c_name":u"教育高清包月大厅","c_key":"educenter_hd","c_type__c_key":"month_report",
                "value":u'''
                     {"app_label":"game","pay_keys":["educenter_hd"],"pv_keys":["eduhipi_hd"]}
                 '''
                },
                {"c_name":u"OTT高清包月大厅","c_key":"hipi_game","c_type__c_key":"month_report",
                "value":u'''
                     {"app_label":"ott","pay_keys":["hipi_game"],"pv_keys":["hipi_game"]}
                 '''
                },
                {"c_name":u"PPV阀值","c_key":"ppv_threshold","c_type__c_key":"threshold","value":1},
                {"c_name":u"包月阀值","c_key":"month_threshold","c_type__c_key":"threshold","value":0.01},
            ]
            for elem in params:
                qs = Type.objects.filter(c_key = elem["c_type__c_key"])
                if qs:
                    is_exists = Params.objects.filter(c_key=elem["c_key"]).exists()
                    if not is_exists:
                        Params(**{
                            "c_key":elem["c_key"],
                            "c_name":u"%s"%elem["c_name"],
                            "c_type":qs[0],
                            "value":elem.pop("value",None)
                        }).save()


class AreaParams(models.Model):
    u"区域参数"
    area = models.ForeignKey(Area, verbose_name=u"区域")
    param = models.ForeignKey(Params, verbose_name=u"参数")
    c_value = models.CharField(u"参数值",max_length=40,blank=True,null=True,help_text=u"默认用params中的value，如果该值配置了，写代码的时候可以覆盖params默认的配置")
    c_memo = models.CharField(u"参数说明",max_length=600,blank=True,null=True)
    
    def __unicode__(self):
        return self.c_value
    
    @classmethod
    def get_area_params(cls,param_type,areacode):
        u"""
        @param_type ->参数类型
        @areacode ->区域代码
        获取某个区域，某种类型的参数
        """
        params = AreaParams.objects.filter(
            area__zcode = areacode,
            param__c_type__c_key=param_type
        ).values("param__value","c_value","param__c_name")
    
        result = {}
        for p in params:
            key = p["param__c_name"]
            value = p["param__value"]
            if p["c_value"]:
                value = p["c_value"]
            result[value] = key
            
        return result
    
    
    class Meta:
        app_label = "system"
        verbose_name = u"区域参数"
        
    class Admin:
        list_fields = [
            "id","area_id","param__c_name","param__c_type__c_name","param_id","c_value","area__zname"
        ]


TABLES = (
    ("t_month_pay_order",u"包月订购表"),
    ("t_pay_orders",u"按次支付表"),
)

CAL_TYPE=(
    ("0", u"自动统计"),
    ("1",u"手动统计"),
    ("2",u"暂不统计"),
)

class Product(models.Model):
    area = models.ForeignKey(Area, verbose_name=u"区域")
    c_name = models.CharField(verbose_name=u"产品名称", max_length=40, blank=True, null=True)
    is_ppv = models.BooleanField(verbose_name=u"是否为PPV产品",blank=True,default=False)
    new_by_hand = models.CharField( u"统计方式", max_length = 2,choices=CAL_TYPE,default="0")
    remark = models.CharField(verbose_name=u"信息摘要",null=True,blank=True,max_length=400)
    create_time = models.DateTimeField(verbose_name=u"创建时间",auto_now_add=True,auto_now=True)

    def __unicode__(self):
        return "{zname} -- {c_name}".format(
                zname=self.area.zname ,
                c_name= self.c_name
        )

    class Meta:
        app_label = "system"
        verbose_name = u"产品"

    class Admin:
        list_fields = [
            "id", "area_id", "area__zcode","new_by_hand", "area__zname",  "c_name", "is_ppv",
            "create_time","remark"
        ]
    

class MonthProduct(models.Model):
    product = models.ForeignKey(Product, verbose_name=u"所属产品")
    c_pay_key = models.CharField(verbose_name=u"支付键值",max_length=40,blank=True,null=True)
    c_pv_key = models.CharField(verbose_name=u"PV键值",max_length=40,blank=True,null=True)
    c_table = models.CharField(verbose_name=u"所存储的表",choices=TABLES,max_length=40,blank=True,null=True)
    ratio = models.DecimalField(verbose_name = u"比例",default=1,null=False,blank=False,max_digits=3, decimal_places=1)
    price = models.IntegerField(verbose_name=u"单价",help_text=u"包月产品的单价")

    def __unicode__(self):
        return "{zname} -- {c_name}".format(
                zname=self.product.area.zname ,
                c_name= self.product.c_name
        )

    class Meta:
        app_label = "system"
        verbose_name = u"包月产品配置"

    class Admin:
        list_fields = [
            "id", "product_id", "product__area__zname","product__area__zcode", "product__c_name", "c_pay_key", "c_pv_key", "c_table", "price","ratio",
        ]
        
        init_index = 1

IS_OR_NO = [["F",u"否"],["T",u"是"],]

class PpvProduct(models.Model):
    product = models.ForeignKey(Product, verbose_name=u"所属产品",related_name="ppv_product")
    c_pv_key = models.CharField(verbose_name=u"PV键值",default="center",max_length=40,blank=True,null=True)
    limit_money = models.IntegerField(verbose_name=u"限额(元)",default=300,help_text=u"按次产品限额")
    is_ott = models.CharField(verbose_name=u"是否OTT产品", max_length=5,choices = IS_OR_NO,default="F",help_text=u"是否OTT产品")

    def __unicode__(self):
        return "{zname} -- {c_name}".format(
                zname=self.product.area.zname ,
                c_name= self.product.c_name
        )
        
    class Meta:
        app_label = "system"
        verbose_name = u"按次产品配置"

    class Admin:
        list_fields = [
            "id", "product_id", "product__area__zname","product__area__zcode", "product__c_name",
            "c_pv_key", "limit_money","is_ott"
        ]


class PpvProductParams(models.Model):
    product = models.ForeignKey(PpvProduct, verbose_name=u"所属产品",related_name="ppv_product_params")
    month = models.DateField(verbose_name=u"月份",null = True,blank=True)
    income_target = models.IntegerField(verbose_name=u"收入指标",null=False,blank=False,default=0)
    remark = models.CharField(verbose_name=u"信息摘要",null=True,blank=True,max_length=400)
    create_time = models.DateTimeField(verbose_name=u"创建时间",auto_now_add=True,auto_now=True)

    @classmethod
    def render_column_month(cls,v):
        return v.strftime("%Y-%m")

    class Meta:
        app_label = "system"
        verbose_name = u"ppv产品配置"

    class Admin:
        list_fields = [
            "id", "product__product__id", "product__product__area__zname", "product__product__c_name", "month", "income_target","remark","create_time"
        ]


class MonthProductParams(models.Model):
    month = models.DateField(verbose_name=u"月份",null = True, blank=True)
    product = models.ForeignKey(MonthProduct, verbose_name=u"产品", null=False, blank=False)
    continue_subscribe_numbers = models.IntegerField(verbose_name=u"续订用户数",null=False,blank=False,default=0)
    income_target = models.IntegerField(verbose_name=u"收入指标",null=False,blank=False,default=0)
    remark = models.CharField(verbose_name=u"信息摘要",null=True,blank=True,max_length=400)
    create_time = models.DateTimeField(verbose_name=u"创建时间",auto_now_add=True,auto_now=True)

    @classmethod
    def render_column_month(cls,v):
        return v.strftime("%Y-%m")

    class Meta:
        app_label = "system"
        verbose_name = u"包月产品配置"

    class Admin:
        list_fields = [
            "id", "product_id", "product__product__area__zname", "product__product__c_name",
            "month","product__c_pay_key","product__c_pv_key", "product__price","continue_subscribe_numbers",
            "income_target", "remark", "create_time"
        ]

def get_complete_rate(v):
    rate = 0
    if v["income_target"]:
        rate = float(v["total_sum_money"])/v["income_target"]
    return u"%.2f%%" % (rate*100)

def get_complete_rate_ppv(v):
    rate = 0
    if v["ppv_income_target"]:
        rate = float(v["ppv_sum_money"])/v["ppv_income_target"]
    return u"%.2f%%" % (rate*100)

def get_complete_rate_monthly(v):
    rate = 0
    if v["monthly_income_target"]:
        rate = float(v["month_sum_money"])/v["monthly_income_target"]
    return u"%.2f%%" % (rate*100)



class IncomeTotalReport(models.Model):
    month = models.DateField(verbose_name=u"月份",null = True, blank=True)
    area = models.ForeignKey(Area, verbose_name=u"区域")
    ppv_sum_money = models.IntegerField(verbose_name=u"PPV流水(成功)",null=True,blank=True,default=0,help_text="不填写，默认为0")
    ppv_income_target = models.IntegerField(verbose_name=u"PPV收入指标",null=True,blank=True,default=0,help_text="不填写，默认为0")
    ppv_complete_rate = models.DecimalField(verbose_name=u"PPV完成度",null=True,blank=True,max_digits=9,decimal_places=5,default=0,help_text="自动计算，不可编辑")
    month_sum_money = models.IntegerField(verbose_name=u"包月流水(成功)",null=True,blank=True,default=0,help_text="不填写，默认为0")
    monthly_income_target = models.IntegerField(verbose_name=u"包月收入指标",null=True,blank=True,default=0,help_text="不填写，默认为0")
    monthly_complete_rate = models.DecimalField(verbose_name=u"包月完成度",null=True,blank=True,max_digits=9,decimal_places=5,default=0,help_text="自动计算，不可编辑")
    total_sum_money = models.IntegerField(verbose_name=u"总流水",null=True,blank=True,default=0,help_text="自动计算，不可编辑")
    income_target = models.IntegerField(verbose_name=u"总收入指标",null=True,blank=True,default=0,help_text="自动计算，不可编辑")
    complete_rate = models.DecimalField(verbose_name=u"总完成度",null=True,blank=True,max_digits=9,decimal_places=5,default=0,help_text="自动计算，不可编辑")
    create_time = models.DateTimeField(verbose_name=u"创建时间",auto_now_add=True,auto_now=True)
    remark = models.CharField(verbose_name=u"信息摘要",null=True,blank=True,max_length=400)

    @classmethod
    def render_column_complete_rate(cls,v):
        try:
            return u"%.2f%%" % (v*100)
        except:
            return 0

    class Meta:
        app_label = "system"
        verbose_name = u"收入汇总表"

    class Admin:
        list_fields = [
            "id", "month", "area_id","area__zcode", "area__zname", "ppv_sum_money","ppv_income_target","ppv_complete_rate",
            "month_sum_money","monthly_income_target","monthly_complete_rate", "total_sum_money", "income_target",
            "complete_rate","create_time", "remark"
        ]
        aggregate = {
            "ppv_sum_money":models.Sum("ppv_sum_money"),
            "ppv_income_target":models.Sum("ppv_income_target"),
            "month_sum_money":models.Sum("month_sum_money"),
            "monthly_income_target":models.Sum("monthly_income_target"),
            "total_sum_money":models.Sum("total_sum_money"),
            "income_target":models.Sum("income_target"),
        }

        static_aggregate = {
            "month":u"总计",
            "complete_rate":get_complete_rate,
            "ppv_complete_rate":get_complete_rate_ppv,
            "monthly_complete_rate":get_complete_rate_monthly,
        }


class ReportType(models.Model):
    c_key = models.CharField(verbose_name=u"报表键值",max_length=40,blank=True,null=True)
    c_name = models.CharField(verbose_name=u"报表名称",max_length=40,blank=True,null=True)

    def __unicode__(self):
        return u"%s" % self.c_name

    class Meta:
        app_label = "system"
        verbose_name = u"报表类型"

    class Admin:
        list_fields = [
            "c_key","c_name",
        ]
        init_index = 1

        @classmethod
        def initial_data(cls):
            u"""
                初始化INITIAL_DICT的记录
            """
            params = [
                {"c_key":u"calculte_monthly_report", "c_name":u"各地区收入完成度报表"},
                {"c_key":u"calculte_day_report", "c_name":u"每日数据分析异动报表"},
            ]
            for elem in params:
                is_exist = ReportType.objects.filter(c_key=elem["c_key"]).exists()
                if not is_exist:
                    ReportType(**{
                        "c_key":elem["c_key"],
                        "c_name":u"%s"%elem["c_name"],
                    }).save()

SEND_TYPES = (
    ("email",u"邮件"),
    ("msg",u"短信"),
)


class ReceiverConfig(models.Model):
    user = models.ManyToManyField(User, verbose_name=u"用户")
    report_type = models.ForeignKey(ReportType,verbose_name=u"报表类型")
    send_type = models.CharField(verbose_name=u"发送类别",max_length=20,default="email",choices=SEND_TYPES)
    create_time = models.DateTimeField(verbose_name=u"创建时间",auto_now_add=True,auto_now=True)

    class Meta:
        app_label = "system"
        verbose_name = u"接收者配置"

    class Admin:
        list_fields = [
            "id",  "report_type__c_name","report_type_id", "send_type", "create_time"
        ]

WARNING_TYPES=(
    (False,u"正常"),
    (True,u"异常"),
)

class PpvDayTotalReport(models.Model):
    area = models.ForeignKey(Area, verbose_name=u"区域")
    fdate = models.DateField(verbose_name=u"日期",null=True,blank=True)
    product_name = models.CharField(verbose_name=u"产品名称",max_length=40,blank=True,null=True)
    dis_hall_access_uv = models.IntegerField(verbose_name=u"大厅访问uv",null=True,blank=True,default=0)
    hall_access_pv = models.IntegerField(verbose_name=u"大厅访问pv",null=True,blank=True,default=0)
    dis_game_start_uv = models.IntegerField(verbose_name=u"游戏启动uv",null=True,blank=True,default=0)
    game_start_pv = models.IntegerField(verbose_name=u"游戏启动pv",null=True,blank=True,default=0)
    p_success_money = models.DecimalField(verbose_name=u"充值成功总金额",null=True,blank=True,max_digits=19,decimal_places=3,default=0)
    p_fail_money = models.DecimalField(verbose_name=u"充值失败总金额",null=True,blank=True,max_digits=19,decimal_places=3,default=0)
    p_success_dis_count = models.IntegerField(verbose_name=u"充值成功用户数",null=True,blank=True,default=0)
    p_total_dis_count = models.IntegerField(verbose_name=u"充值总用户数",null=True,blank=True,default=0)
    p_total_count = models.IntegerField(verbose_name=u"充值总次数",null=True,blank=True,default=0)
    success_percent = models.DecimalField(verbose_name=u"充值成功率",null=True,blank=True,max_digits=9,decimal_places=5,default=0)
    day_new_user = models.IntegerField(verbose_name=u"大厅新增用户数",null=True,blank=True,default=0)
    p_new_add_count = models.IntegerField(verbose_name=u"新增充值用户数",null=True,blank=True,default=0)
    ARPU = models.DecimalField(verbose_name=u"人均ARPU",null=True,blank=True,max_digits=9,decimal_places=5,default=0)
    c_success_money = models.DecimalField(verbose_name=u"消费成功金额",null=True,blank=True,max_digits=19,decimal_places=3,default=0)
    c_fail_money = models.DecimalField(verbose_name=u"消费失败金额",null=True,blank=True,max_digits=19,decimal_places=3,default=0)
    c_total_dis_count = models.IntegerField(verbose_name=u"消费用户数",null=True,blank=True,default=0)
    c_total_count = models.IntegerField(verbose_name=u"消费次数",null=True,blank=True,default=0)
    c_new_add_count = models.IntegerField(verbose_name=u"新增消费用户数",null=True,blank=True,default=0)
    count_month_limit_user = models.IntegerField(verbose_name=u"消费已达上限用户数",null=True,blank=True,default=0)
    month_limit_money = models.DecimalField(verbose_name=u"月消费限额",null=True,blank=True,max_digits=19,decimal_places=3,default=0)
    coins_percent = models.DecimalField(verbose_name=u"流量转化值",null=True,blank=True,max_digits=19,decimal_places=3,default=0,help_text=u"自动计算，不用填")
    daily_pay_percent = models.DecimalField(verbose_name=u"日付费率",null=True,blank=True,max_digits=9,decimal_places=5,default=0)
    total_user = models.IntegerField(verbose_name=u"历史累计总用户数",null=True,blank=True,default=0)
    total_pay_user = models.IntegerField(verbose_name=u"历史累计付费用户数",null=True,blank=True,default=0)
    no_pay_user = models.IntegerField(verbose_name=u"历史累计从来没有付费的用户数",null=True,blank=True,default=0)
    is_warning = models.BooleanField(verbose_name=u"是否预警",blank=True,default=False,choices=WARNING_TYPES)
    create_time = models.DateTimeField(verbose_name=u"创建时间",auto_now_add=True,auto_now=True)
    remark = models.CharField(verbose_name=u"信息摘要",null=True,blank=True,max_length=400)

    class Meta:
        app_label = "system"
        verbose_name = u"PPV汇总表"

    @classmethod
    def render_column_success_percent(cls,v):
        try:
            return "%.2f%%"%(v*100)
        except:
            return 0

    @classmethod
    def render_column_daily_pay_percent(cls,v):
        try:
            return "%.2f%%"%(v*100)
        except:
            return 0

    class Admin:
        list_fields = [
            "id","fdate","product_name","area__id","area__zname","area__zcode","dis_hall_access_uv","hall_access_pv","dis_game_start_uv",
            "game_start_pv","p_success_money","p_fail_money","p_success_dis_count","p_total_dis_count","p_total_count",
            "success_percent","day_new_user","p_new_add_count","ARPU","c_success_money","c_fail_money","c_total_dis_count",
            "c_total_count","c_total_count","c_new_add_count","count_month_limit_user","month_limit_money","coins_percent",
            "daily_pay_percent","total_user","total_pay_user","no_pay_user","is_warning","create_time","remark",
        ]
        aggregate = {
            "dis_hall_access_uv":models.Sum("dis_hall_access_uv"),
            "p_success_money":models.Sum("p_success_money"),
            "c_success_money":models.Sum("c_success_money"),
            "day_new_user":models.Sum("day_new_user"),
            "coins_percent":models.Avg("coins_percent"),
        }

        static_aggregate = {
            "fdate":u"总计",
            "product_name":u"PPV产品",
        }


class MonthDayTotalReport(models.Model):
    area = models.ForeignKey(Area, verbose_name=u"区域")
    fdate = models.DateField(verbose_name=u"日期",null=True,blank=True)
    product_name = models.CharField(verbose_name=u"产品名称",max_length=40,blank=True,null=True)
    dis_hall_access_uv = models.IntegerField(verbose_name=u"大厅访问用户数",null=True,blank=True,default=0)
    hall_access_pv = models.IntegerField(verbose_name=u"大厅访问次数",null=True,blank=True,default=0)
    p_success_dis_count = models.IntegerField(verbose_name=u"成功订购用户数",null=True,blank=True,default=0)
    c_percent = models.DecimalField(verbose_name=u"转换率",null=True,blank=True,max_digits=19,decimal_places=3,default=0)
    dis_order_page_user_uv = models.IntegerField(verbose_name=u"订购页面访问uv",null=True,blank=True,default=0)
    day_new_user = models.IntegerField(verbose_name=u"大厅新增用户数",null=True,blank=True,default=0)
    dis_total_first_login_and_order_user = models.IntegerField(verbose_name=u"第一次进来并订购的用户数",null=True,blank=True,default=0)
    dis_hall_already_order_count = models.IntegerField(verbose_name=u"已经订购的访问用户",null=True,blank=True,default=0)
    success_percent = models.DecimalField(verbose_name=u"订购成功率",null=True,blank=True,max_digits=19,decimal_places=3,default=0)
    p_fail_dis_count = models.IntegerField(verbose_name=u"失败订购用户数",null=True,blank=True,default=0)
    dis_game_start_uv = models.IntegerField(verbose_name=u"游戏启动uv",null=True,blank=True,default=0)
    game_start_pv = models.IntegerField(verbose_name=u"游戏启动pv",null=True,blank=True,default=0)
    p_success_money = models.DecimalField(verbose_name=u"成功总金额",null=True,blank=True,max_digits=19,decimal_places=3,default=0)
    p_subscribe_success_money = models.DecimalField(verbose_name=u"当天续订总金额",null=True,blank=True,max_digits=19,decimal_places=3,default=0)
    p_fail_money = models.DecimalField(verbose_name=u"失败总金额",null=True,blank=True,max_digits=19,decimal_places=3,default=0)
    p_new_add_count = models.IntegerField(verbose_name=u"新增订购用户数",null=True,blank=True,default=0)
    order_page_user_pv = models.IntegerField(verbose_name=u"订购页面访问pv",null=True,blank=True,default=0)
    total_user = models.IntegerField(verbose_name=u"历史累计总用户数",null=True,blank=True,default=0)
    total_pay_user = models.IntegerField(verbose_name=u"历史累计订购用户数",null=True,blank=True,default=0)
    no_pay_user = models.IntegerField(verbose_name=u"历史累未订购用户数",null=True,blank=True,default=0)
    is_warning = models.BooleanField(verbose_name=u"是否预警",blank=True,default=0,max_length=20,choices=WARNING_TYPES)
    create_time = models.DateTimeField(verbose_name=u"创建时间",auto_now_add=True,auto_now=True)
    remark = models.CharField(verbose_name=u"信息摘要",null=True,blank=True,max_length=400)

    @classmethod
    def render_column_c_percent(cls,v):
        try:
            return u"%.2f%%" %( v*100)
        except:
            return 0

    @classmethod
    def render_column_success_percent(cls,v):
        try:
            return u"%.2f%%" %( v*100)
        except:
            return 0


    class Meta:
        app_label = "system"
        verbose_name = u"包月汇总表"

    class Admin:
        list_fields = [
                "id","fdate","area__id","area__zname","area__zcode","dis_hall_access_uv","hall_access_pv","p_success_dis_count","c_percent",
                "dis_order_page_user_uv","day_new_user","dis_total_first_login_and_order_user","dis_hall_already_order_count","success_percent",
                "p_fail_dis_count","dis_game_start_uv","game_start_pv","p_success_money","p_subscribe_success_money","p_fail_money","p_new_add_count","order_page_user_pv",
                "total_user","total_pay_user","no_pay_user","product_name","is_warning","create_time","remark",
        ]
        aggregate = {
            "dis_hall_access_uv":models.Sum("dis_hall_access_uv"),
            "p_success_money":models.Sum("p_success_money"),
            "day_new_user":models.Sum("day_new_user"),
            "p_subscribe_success_money":models.Sum("p_subscribe_success_money"),
        }
        static_aggregate = {
            "fdate":u"总计",
            "product_name":u"包月产品",
        }

RECORD_TYPES = (
    ("buy",u"充值明细"),
    ("consume",u"消费明细"),
    ("month",u"包月订购明细"),
    ("respv",u"资源PV明细"),
)


class SyncLog( models.Model ):
    u"""
    正常订单同步日志
    """
    areaname = models.CharField( u"专区名称", null = True,blank=True, default = None, max_length=50,help_text = u"数据来源于哪个地区" )
    areacode = models.CharField( u"专区代码", null = True,blank=True, default = None, max_length=50,help_text = u"数据来源于哪个地区码" )
    record_type = models.CharField( u"订单类型", null = True,blank=True, choices=RECORD_TYPES,default = None, max_length=80,help_text = u"" )
    max_order_id = models.IntegerField( u"最大订ID", null = True,blank=True, default = 0, help_text = u"" )
    total_count = models.IntegerField( u"记录总数", null = True,blank=True, help_text = u"" )
    hour = models.IntegerField( u"记录创建的小时", null = True,blank=True, help_text = u"" )
    create_date = models.DateField( verbose_name=u"记录创建日期",db_index = True, null = False, auto_now_add=True, )
    area_db_datehour = models.DateTimeField( verbose_name=u"地区数据库的时间",db_index = True, null = True, help_text=u"这个时间前面的记录表示都已经传完了" )
    create_datetime = models.DateTimeField( verbose_name=u"记录创建时间",db_index = True, null = False, auto_now_add=True )
    remart = models.CharField(verbose_name = u"备注",max_length=100, null=True,blank=True,db_index=True)
    enable       = models.CharField( u"是否有效", max_length = 2,choices=YES_OR_NO, null = False, blank=False,default="T",help_text = u"暂时没用" )
    
    class Admin:
        list_fields = [
            "id","areaname","areacode","record_type","max_order_id","total_count","hour",
            "create_date","area_db_datehour","create_datetime","remart","enable",
        ]
    
    class Meta:
        db_table = "collect_data_synclog"   
        verbose_name = u"同步日志"

WAIT_FOR_PROCESS = -1
SUCCESS = 0

RETRY_STATUS = (
    (WAIT_FOR_PROCESS,u"待处理"),
    (SUCCESS,u"处理成功"),
)
        

class RetryTask(models.Model):
    u"""
    订单重传日志,因为怕时间处理过长如果直接用http的方式不太友好，
    可以通过下达任务的方式告诉脚本去执行，并返回执行结果
    """
    areaname = models.CharField( u"专区说明", null = True,blank=True, default = None, max_length=50,help_text = u"数据来源于哪个地区" )
    areacode = models.CharField( u"专区代码", null = True,blank=True, default = None, max_length=50,help_text = u"数据来源于哪个地区码" )
    record_type = models.CharField( u"订单类型", null = True,blank=True, choices=RECORD_TYPES,default = None, max_length=80,help_text = u"" )
    retry_start_time = models.DateTimeField( verbose_name=u"重传哪个时间段的记录（开始）",db_index = True, null = False )
    retry_end_time = models.DateTimeField( verbose_name=u"重传哪个时间段的记录（结束）",db_index = True, null = False )
    c_status = models.IntegerField( u"处理结果", null = True,blank=True,default=WAIT_FOR_PROCESS, help_text = u"处理状态" )
    process_end_time = models.DateTimeField( verbose_name=u"任务处理结束时间",null = True,blank=True )
    create_datetime = models.DateTimeField( verbose_name=u"任务创建时间",db_index = True, null = False, auto_now_add=True )
    enable       = models.CharField( u"是否有效", max_length = 2,choices=YES_OR_NO, null = False, blank=False,default="T",help_text = u"暂时未用" )
    
    class Admin:
        list_fields = [
            "id","areaname","areacode","record_type","retry_start_time","retry_end_time","c_status",
            "process_end_time","create_datetime",
        ]
    
    
    class Meta:
        verbose_name = u"订单重传日志"
        db_table = "collect_data_retrytask"
        
        
class TestUser(models.Model):
    areaname = models.CharField( u"专区说明", null = False,blank=False, default = None, max_length=50,help_text = u"数据来源于哪个地区" )
    c_userid = models.CharField(verbose_name = u"用户ID",max_length=80,null=False,blank=False)
    create_datetime = models.DateTimeField( verbose_name=u"任务创建时间",db_index = True, null = False, auto_now_add=True )
    remark = models.CharField(verbose_name = u"备注",max_length=50,null=True,blank=True)
    
    class Admin:
        list_fields = [
            "id","areaname","c_userid","create_datetime","remark",
        ]
    
    
    class Meta:
        verbose_name = u"地区测试用户"
        db_table = "collect_data_testuser"
    

BUSINESS_TYPES =  [["game",u"游戏"],["edu_hipi",u"教育"],["ott",u"OTT"],["video",u"电竞"],["chess",u"棋牌"]]

class DatabaseManage(models.Model):
    u"""
    数据库的连接，通过后台管理，密码的话加密，解密一下，
    平台自动检测并连接是否存在，不存在自动加入
    """
    django_name = models.CharField(verbose_name=u"连接名称",null=True, blank=True,max_length=80)
    engine = models.CharField( u"数据库引擎", null = True,blank=True, default = "django.db.backends.mysql", max_length=50,help_text = u"数据库类别" )
    dbname = models.CharField( u"数据库名称", null = True,blank=True, default = None, max_length=50,help_text = u"数据库名称" )
    username = models.CharField( u"用户名", null = True,blank=True, default = None, max_length=50,help_text = u"数据库账号" )
    password = models.CharField( u"密码", null = False,blank=False, default = None, max_length=50,help_text = u"数据库密码" )
    host = models.CharField( u"部署后台使用的数据库IP", null = False,blank=False, default = None, max_length=50,help_text = u"IP" )
    is_main_db = models.CharField( u"是否主数据库", max_length = 2,blank=True,choices=YES_OR_NO2,default = "F", help_text = u"是否是主数据库" )
    applabel = models.CharField( u"所属应用", null = False,blank=False, choices=BUSINESS_TYPES, default = None, max_length=50,help_text = u"是什么业务的数据库" )
    game_host = models.CharField( u"游戏服务器使用的数据库IP", null = False,blank=False, default = None, max_length=50,help_text = u"IP" )
    port = models.CharField( u"端口", null = False,blank=False, default = "3306", max_length=50,help_text = u"数据库端口" )
    auto_create_db = models.BooleanField(u"是否自动创建数据库",default=False,help_text=u"当发现数据库没有的时候，是否自动创建数据库")
    parent = models.ForeignKey("DatabaseManage", verbose_name=u"所属父级",related_name="cc",on_delete=models.SET_NULL, null=True,blank=True,help_text=u"一个区域有多个数据库连接,分成组")
    remark = models.CharField(u"备注",null=True, blank=True,max_length=500,help_text = u"解释说明")

    def __unicode__(self):
        return u"{remark}-{dbname}-{django_name}-{applabel}-{is_main_db}".format(
            dbname = self.dbname,
            django_name=self.django_name,
            applabel = self.applabel,
            is_main_db = self.is_main_db,
            remark = self.remark
        )

    class Admin:
        list_fields = ["id","django_name","engine","dbname","username","password","port","host","is_main_db","applabel","auto_create_db","parent__django_name","remark"]


    class Meta:
        verbose_name = u"数据库管理"
        app_label = "system"



class DataSyncConfig(models.Model):
    u"""
    导数据配置
    """
    db = models.ForeignKey(DatabaseManage,verbose_name=u"数据库连接",null=False,blank=False)
    is_consume_pay_on = models.CharField( u"是否有充值消费", max_length = 2,blank=True,choices=YES_OR_NO2,default = "T", help_text = u"" )
    is_pv_on = models.CharField( u"是否有pv", max_length = 2,blank=True,choices=YES_OR_NO2,default = "T", help_text = u"" )
    is_edu_resource_on = models.CharField( u"是否有教育资源", max_length = 2,blank=True,choices=YES_OR_NO2,default = "F", help_text = u"" )
    is_month_pay_on = models.CharField( u"是否有包月",max_length = 2, blank=True,choices=YES_OR_NO2,default = "F", help_text = u"" )
    is_loginpv_on = models.CharField( u"是否有登入PV",max_length = 2, blank=True,choices=YES_OR_NO2,default = "T", help_text = u"" )
    is_user_on = models.CharField( u"是否有用户",max_length = 2, blank=True,choices=YES_OR_NO2,default = "T", help_text = u"" )
    alias = models.CharField( u"公司数据库名称",max_length = 50, blank=True, help_text = u"由于各个地区有些数据库名称相同，公司内的数据库都放一起，所以通过这个字段自动创建不一样的" )
    merge_with_end = models.CharField( u"最后一个合并的数据库",max_length = 2, blank=True,choices=YES_OR_NO2,default = "T", help_text = u"由于几个数据库的数据需要合并，所以只配置一个需要合并的连接" )
    enable       = models.CharField( u"是否有效", max_length = 2,choices=YES_OR_NO2, null = False, blank=False,default="T",help_text = u"暂时未用" )
    
    class Admin:
        list_fields = [
            "id","db__django_name","db__dbname","db__host","is_consume_pay_on","is_pv_on","is_edu_resource_on",
            "is_month_pay_on","is_loginpv_on","is_user_on","alias","merge_with_end","enable",
        ]
        
    class Meta:
        verbose_name = u"导数据配置"
        app_label = "system"
    

class SqlRecord(models.Model):
    userid = models.CharField( u"用户", null = True,blank=True,  max_length=50 )
    sql = models.CharField( u"SQL", null = True,blank=True,  max_length=4096 )
    create_datetime = models.DateTimeField( verbose_name=u"创建时间",db_index = True, null = False, auto_now_add=True )
    
    
    class Admin:
        list_fields = ["id","userid","create_datetime"]
    
    class Meta:
        verbose_name = u"SQl记录"
        app_label = "system"
        

class UserRowPermission(models.Model):
    areacode =  models.CharField(verbose_name = u"地区编码", max_length=150,blank=True, null=True,help_text=u"行级权限所属区域")
    user = models.ForeignKey(User,related_name = "up_user",verbose_name = u"用户",blank=True,null=True)
    all_filters =  models.CharField(verbose_name = u"所有模块的过滤条件", max_length=1024,blank=True, null=True,help_text=u"""
        {{areacode}}:{   
            "{{app_label}}__{{model_name}}":{
                "filters":{},
                "filters_ors":[[],...],
                "excludes":{},
                "excludes_ors":[[],...]
            },
            ...
        }
        """
    )
    remark = models.CharField(verbose_name = u"备注",max_length = 300,blank=True,null=True)
    create_datetime = models.DateTimeField( verbose_name=u"创建时间",db_index = True, null = False, auto_now_add=True )
    enable = models.CharField( u"是否有效", max_length = 2,choices=YES_OR_NO, null = False, blank=False,default="T",help_text = u"是否有效" )

    class Admin:
        list_fields = ["id","areacode","user__username","content_type__model","content_type__name","filters","ors","excludes","create_datetime"]
    
    class Meta:
        verbose_name = u"用户行级权限"
        app_label = "system"
    


def get_edit_cls(model_name):
    u"""
        获取当前编辑的类
    """
    from views_edit import ProductEdit, MonthProductEdit

    all_edit_cls = {
        "Product": ProductEdit,
        "MonthProduct": MonthProductEdit,
    }

    if model_name in all_edit_cls:
        return all_edit_cls[model_name]

    return None


def database_init(sender, **kwargs):
    from django.db import connection
    if 'mysql' in connection.__module__:
        connection.cursor().execute('set autocommit=1')
     
from django.db.backends.signals import connection_created
connection_created.connect(database_init)
