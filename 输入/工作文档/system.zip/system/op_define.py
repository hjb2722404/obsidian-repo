# -*- coding: utf-8 -*-
from django.db.models import Model
from django.utils.translation import ugettext_lazy as _
from django.db import models

#需要初始化的类别
#以后改为XML方式加载
INITIAL_DICT  = [
    {"type_code":u"delete","verbose_name":u"删除",},
    {"type_code":u"add","verbose_name":u"新增",},
    {"type_code":u"change","verbose_name":u"修改",},
    {"type_code":u"svn_update","verbose_name":u"SVN更新",},
    {"type_code":u"svn_release","verbose_name":u"SVN发布",},
    {"type_code":u"svn_update_check","verbose_name":u"客户端确认更新OK",},
    {"type_code":u"sync_resource","verbose_name":u"同步应用资源",},
    {"type_code":u"apache_restart","verbose_name":u"重启Apache",},
    {"type_code":u"apache_reload","verbose_name":u"重新加载Apache",},
    {"type_code":u"syncdb_table","verbose_name":u"同步表结构",},
    {"type_code":u"export","verbose_name":u"导出",},
    {"type_code":u"import","verbose_name":u"导入",},
    {"type_code":u"exe_sql","verbose_name":u"执行SQL",},
]
