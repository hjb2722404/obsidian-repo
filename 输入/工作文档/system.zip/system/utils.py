# -*- coding: utf-8 -*-
from system.models import Area
from system.models import AreaPermission
from django.shortcuts import render_to_response
from django.http import HttpResponse
from django.db import models
import json
import copy
import types

def check_and_get_user_model_row_permission(user_model_row_perms,model,areacode="00000"):
    is_open_row_perms = False
    if hasattr(model.Admin,"is_open_row_perms") and model.Admin.is_open_row_perms:
        is_open_row_perms = True

    key = ("%s__%s"%(model._meta.app_label,model.__name__)).lower()
    row_perms = None
    if areacode in user_model_row_perms:
        area_row_perms = user_model_row_perms[areacode]
        if key in area_row_perms:
            row_perms = area_row_perms[key]

    return is_open_row_perms,row_perms

def get_all_models_related(user_model_row_perms,model_class,related_path=None,all_query = None,all_models = None):
    u"""
    找到所有与该模型有关联的model，比如外键，比如多对多，比如一对一
    """
    if  all_query is None:
        all_query = []
        
    if all_models is None:
        all_models = []
    
    all_models.append(model_class)
    result = {
        "app_label":model_class._meta.app_label,
        "model":model_class,
        "related_path":related_path if related_path else [],
    }

    is_open,row_perms = check_and_get_user_model_row_permission(
        user_model_row_perms = user_model_row_perms,
        model=model_class,
        areacode="00000",
    )

    if is_open: #设置了行权限控制
        prex = result["related_path"]
        p = {
            "filters":{},
            "excludes":{},
            "filters_ors":[],
            "excludes_ors":[],
        }
        if row_perms:
            for k,v in row_perms["excludes"].items():
                prex_key1 = copy.deepcopy(prex)
                prex_key1.append(k)
                new_key = "__".join(prex_key1)
                p.setdefault("excludes",{})[new_key] = v

            for k,v in row_perms["filters"].items():
                prex_key2 = copy.deepcopy(prex)
                prex_key2.append(k)
                new_key = "__".join(prex_key2)
                p.setdefault("filters",{})[new_key] = v


            for elem in row_perms["excludes_ors"]:
                prex_key3 = copy.deepcopy(prex)
                prex_key3.append(elem)
                p.setdefault("excludes_ors",[]).append(prex_key3)

            for elem in row_perms["filters_ors"]:
                prex_key4 = copy.deepcopy(prex)
                prex_key4.append(elem)
                p.setdefault("filters_ors",[]).append(prex_key4)

        else: #没有分配权限的默认全部查询不到
            prex.append("id__exact")
            p= {
                "filters":{"__".join(prex):-1},
                "filters_ors":[],
                "excludes_ors":[],
                "excludes":{},
            }

        all_query.append(p)

    for f in model_class._meta.fields:
        if isinstance(f,models.ForeignKey):
            t = copy.deepcopy(result["related_path"])
            t.append(f.name)
            if f.related.parent_model not in all_models:
                result.setdefault("nodes",[]).append(
                    get_all_models_related(
                        user_model_row_perms=  user_model_row_perms,
                        model_class = f.related.parent_model,
                        related_path = t,
                        all_query = all_query,
                    )
                )


    return result

def get_areas_for_user(user_obj,system_area_row_perms):
    u'''
    通过账号得到所分配的区域
    '''
    from base_api.views import get_row_perms
    if user_obj.is_superuser:
        qs = list(Area.objects.all())
    else:
        qs = list(get_row_perms(Area.objects.all(),system_area_row_perms))
    return qs


def has_perm(user,area,user_perms,perm_name):
    u"""
        @user 用户信息
        @area 区域
        @user_perms 用户的所有权限
        @perm_name 是否具有这个权限
    """
    #区域权限
    
    if user.is_superuser:
        return True
    
    if perm_name.find("__system__") != -1: #系统区域不判断区域权限
        is_ok = True
    else:
        if not area:
            return False
        area_perms = AreaPermission.get_area_perms(area.zcode)
        is_ok = filter(lambda x:x.codename == perm_name,area_perms)
    
    if not is_ok:
        return False
    
    #用户权限
    is_ok =  filter(lambda x:x == "system.%s"%perm_name, user_perms)
    
    if not is_ok:
        return False
    
    return True 

def decorate_auth_user(permission_name):
    u"""
    判断用户某个区域的模块权限
    @permission_name 这个可以自定义一个函数
    """
    def check_perm(func):
        from base_api.base_remote import BaseRemote
        def run(request,*args,**kwargs):
            u"""
                1、用户是否有分配到这个区域
                2、用户是否分配了该模块权限
                3、区域是否拥有这个权限
            """
            #用户是否有权限
            if issubclass(request.__class__,BaseRemote):
                request = request.request
            
            true_perm_name = permission_name
            
            #正对于那种动态生成的权限
            if callable(permission_name):
                true_perm_name = permission_name(request,*args,**kwargs)
            
            ret_error_auth  = { "rows":[], "message":u"权限不够，认证失败", "code":-9998 }
            
            user_own_perms = request.session["perms"] #用户已经拥有的权限
            current_area = request.session.get("area",None) #获取区域
            
            if type(true_perm_name) != types.ListType:
                true_perm_name = [true_perm_name]
                
            for one_perm in true_perm_name:
                is_ok = has_perm(request.user,current_area,user_own_perms,one_perm)
                if is_ok:
                    break
            
            if not is_ok:
                if request.is_ajax():
                    return HttpResponse(json.dumps(ret_error_auth))
                else:
                    return render_to_response("system/auth_fail.html")
            
            return func(request,*args,**kwargs)
            
        return run
    
    return check_perm

@decorate_auth_user("browse__system__user")
def tt(request,p1,p2,k1="oo"):
    print 'ok'
    

if __name__ == "__main__":
    tt("1","2","3",k1="4")
